# Summary

Place the chained 20 m Bikanwarda encounter near the universal initial spawn with a column and pedestal.

## Scope

- Resolve a shared initial-spawn/encounter anchor against the existing spawn policy, including first-spawn selection and explicit start positions.
- Assemble boss, column, pedestal, chain sockets, ground fit, and encounter bounds with enough room for attacks and movement.
- Declare how authored encounter ground shaping participates in terrain dependencies if needed; avoid post-spawn corrective geometry scans.
- Ensure boss position is tied to the intended world anchor rather than silently following every player respawn.

## Acceptance criteria

- [ ] The intended universal start has one accessible encounter near it.
- [ ] Boss, column, and chain are aligned to terrain and chain anchors remain coherent.
- [ ] Streaming across the encounter boundary does not spawn duplicates.
- [ ] Encounter remains testable with placeholder assets until final presentation lands.

## Validation

- Inspect the initial start and explicit-start configuration, uneven terrain, departure/re-entry, and restart.

## Dependencies and delivery boundary

- [B01: Add HCSG boss generation and Scripted authoring](../boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Confirm the universal initial spawn anchor given the current first-spawn picker, desired distance, and whether the arena needs terrain flattening.

## Relevant links

- [Initial terrain player spawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/player/src/player.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Barking mob generation/presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/barking/src/hcsg.rs)
- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](../epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
