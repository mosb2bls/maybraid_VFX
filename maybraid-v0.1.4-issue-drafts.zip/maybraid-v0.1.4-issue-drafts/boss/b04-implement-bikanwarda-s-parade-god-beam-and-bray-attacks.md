# Summary

Compose Bikanwarda's three moves using shared boss attack execution.

## Scope

- Parade of Explosions: warn with a line radiating toward the player, then sequence explosion hazards along it using existing fiery-explosion presentation.
- God Beam: warn with eye glow, then activate a 7 m laser column descending from the heavens for 10 seconds.
- Bray: play a head flick, emit sonic waves, and dispatch spatial rumble; synchronize any heavy landing impact with a separate impact cue.
- Author configuration for geometry, timing, damage, aiming, and recovery. Reuse attacks unchanged for summon forms apart from victim policy.

## Acceptance criteria

- [ ] Each warning predicts its actual hazard position and timing.
- [ ] Parade progression, ten-second beam lifetime, and Bray wave/animation timing are visible in a repeatable encounter.
- [ ] Sleep, death, and despawn stop appropriate attacks and clear eye glow.
- [ ] All attacks produce attributed Hit messages and obey configured ally/self victim policies.

## Validation

- Run each attack alone, then the encounter sequence; inspect warning cancellation and hit cadence with placeholder and final VFX.

## Dependencies and delivery boundary

- [B03: Add reusable boss attack timing, hazards, and telegraphs](../boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Confirm beam diameter versus radius, target lock/tracking, obstruction by cover, Parade spacing/direction, Bray spread/range, and damage values.
- VFX/animation issues A01, A02, A09, A10, and A08 provide final presentation; placeholder attack execution can land first.

## Relevant links

- [Fiery explosion effect](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/effects/fiery_explosion.rs)
- [Blast overlap, falloff, and hit collection](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/items/grenades/src/lib.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Existing eye/face material](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/shaders/src/face_material.rs)
- [Quadruped animation implementation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/animations/src/rigs/quadruped.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](../epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
