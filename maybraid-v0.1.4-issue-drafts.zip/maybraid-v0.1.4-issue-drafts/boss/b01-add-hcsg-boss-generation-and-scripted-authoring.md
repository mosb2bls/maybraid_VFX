# Summary

Represent authored boss encounters through HCSG while leaving a compatible path for future generated bosses.

## Scope

- Define stable encounter/boss identity, bounds, ground dependency, actor recipe, attack configuration, and authored placement inputs.
- Establish a small Scripted<T> pattern for authored selection/configuration which feeds the shared boss model.
- Use GenerationContext for dependencies and HcsgNode/PresentationPlugin for presentation; generation remains a function of identity and session roots.
- Keep mutable health, chain durability, unlocks, and phase progress outside generated Arc values. Show the generated-boss extension seam without building a full procedural boss generator.

## Acceptance criteria

- [ ] Bikanwarda's authored definition generates deterministically from seeded inputs and ground.
- [ ] Discovery returns the encounter only for relevant regions; presentation is unique and cleans up its owned hosts.
- [ ] Scripted and future generated definitions can share runtime attacks and presentation.
- [ ] Rebuilding generated data does not itself decide encounter completion or unlock rewards.

## Validation

- Exercise identity/bounds, missing ground, presentation churn, and session restart.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Relevant links

- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [GenerationScheme and GenerationContext](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg/context.rs)
- [Barking mob generation/presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/barking/src/hcsg.rs)
- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](../epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
