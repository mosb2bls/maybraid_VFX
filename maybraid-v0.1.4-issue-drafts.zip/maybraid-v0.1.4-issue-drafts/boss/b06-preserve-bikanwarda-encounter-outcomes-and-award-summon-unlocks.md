# Summary

Track the chained encounter's durable state and resolve killing or freeing Bikanwarda into distinct Lubikan unlocks.

## Scope

- Key mutable encounter progress by stable encounter identity outside HCSG generated values.
- Track relevant live progress and terminal outcomes: killed unlocks Enraged, chain broken/free unlocks Ward.
- Resolve simultaneous kill/break signals deterministically and award each allowed unlock only once.
- Specify stream-out, player death, session reset, and save/load policy; presentation teardown is not a gameplay death or reward event.

## Acceptance criteria

- [ ] Killing Bikanwarda awards Enraged; freeing her through chain break awards Ward.
- [ ] Re-entering the area does not repair completed chains or recreate a completed encounter under the configured lifetime policy.
- [ ] Duplicate outcome messages do not duplicate inventory entries.
- [ ] Player/body replacement does not accidentally reset world encounter progress.

## Validation

- Test duplicate signals, same-frame kill/free, stream-out/re-entry, player death, and chosen persistence boundary.

## Dependencies and delivery boundary

- [B01: Add HCSG boss generation and Scripted authoring](../boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md)
- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Decide whether unlocks are exclusive or both can eventually be earned and what she does immediately after release.
- Decide persistence across game restarts. If the repository lacks required save support, split its implementation as an explicit follow-up rather than claiming disk persistence.

## Relevant links

- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](../epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
