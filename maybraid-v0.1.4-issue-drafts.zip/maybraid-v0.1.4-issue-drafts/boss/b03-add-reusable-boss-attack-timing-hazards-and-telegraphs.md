# Summary

Provide shared attack execution for authored encounters and summoned/generated bosses.

## Scope

- Represent windup, target snapshot/aim policy, execution, recovery, cooldown, and interruption.
- Separate authoritative hazard geometry/damage cadence from VFX; send damage through Hit.
- Own attack instances and effect handles so cancellation, death, sleep, and actor retirement clean up correctly.
- Support repeated area damage and moving wavefronts with explicit per-target hit policy; integrate targeting without fabricating visual contacts.

## Acceptance criteria

- [ ] An attack can run with placeholder or disabled VFX and still apply its specified damage.
- [ ] Each target is damaged at the configured cadence without duplicate collider hits.
- [ ] Attack cancellation removes active hazards and warning states.
- [ ] Encounter and summoned Bikanwarda can invoke the same attack definitions.

## Validation

- Exercise stage boundaries, interruption, multiple colliders per target, frame-rate variation, target loss, and owner despawn.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Default attack damage, cooldowns, interruption policy, and friendly-fire rules must be authored explicitly.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Blast overlap, falloff, and hit collection](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/items/grenades/src/lib.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Combat targeting](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/targeting.rs)
- [Independent target membership sources](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/source.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](../epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
