# Summary

Add Bikanwarda's health-triggered sleep/recovery behavior as explicit live encounter state.

## Scope

- Enter sleep when health crosses to 20% or lower while eligible; cancel incompatible attacks.
- Maintain a 15-second game-time sleep/recovery session intended to restore health to 50%.
- Support early waking when damage brings sleeping health to 10% or lower.
- Define death precedence, repeated threshold crossings, recovery on interruption, and presentation restoration through explicit states.

## Acceptance criteria

- [ ] 20% crossing enters sleep once for the configured phase policy.
- [ ] 15-second completion restores the agreed health amount and returns control.
- [ ] 10% crossing wakes her according to the agreed interruption policy; lethal damage cannot resurrect her.
- [ ] Phase state is not reconstructed from current health alone after streaming.

## Validation

- Test exact thresholds, a hit crossing both thresholds, death during sleep, heal/damage ordering, pause, and re-entry.

## Dependencies and delivery boundary

- [B03: Add reusable boss attack timing, hazards, and telegraphs](../boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)
- [B06: Preserve Bikanwarda encounter outcomes and award summon unlocks](../boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Blocking design decisions: one-time versus repeatable sleep; gradual regeneration versus end-of-sleep restoration; whether early wake cancels remaining recovery.
- Preserve these as explicit configuration/decisions rather than silently choosing a new combat rule.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Character motion integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/motion/README.md)
- [Parent draft: Build the scripted Bikanwarda boss encounter](../epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
