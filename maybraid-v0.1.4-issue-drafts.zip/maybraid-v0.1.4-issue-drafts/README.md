# Maybraid v0.1.4 — Bikanwarda and Lubikan issue drafts

These are draft issue bodies for review and publication: **4 epics and 32 implementation issues**. They are grounded in [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). No issues have been published.

## Delivery structure

| Epic | Children | Delivery boundary |
| --- | --- | --- |
| [E01: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md) | 9 | Ship immediately through Self; no boss dependency. |
| [E02: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md) | 6 | Gameplay can develop against placeholder presentation. |
| [E03: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md) | 13 | Independent playground deliveries and final assembly. |
| [E04: Add Bikanwarda Ward and Enraged summons](epics/e04-summon-epic.md) | 4 | Extends Self framework; never blocks its release. |

## First shippable milestone: Self

Self is a real implementation of the Lubikan contract, not a placeholder for Bikanwarda. Deliver ordinary interaction points → Self charge → readiness → activation → healing with the charge HUD and flying-point feedback. The no-boss validation gate is L09.

- L01 establishes state and fallback.
- L02 supplies authoritative points/charge outcomes; L03 independently supplies damage history.
- L04 implements Self healing using L01–L03.
- L06 implements category selection/cycling; L07 supplies the HUD; L08 adds flying points.
- L05 supplies generic occupancy rewards in parallel and can be demonstrated with a configured Self rule.
- L09 integrates and verifies the independent playable loop. Its hard prerequisites do not include L05's full cell-rule delivery or any B/A/S issue.

## Boss and asset sequence

B01/B02 establish deterministic authored generation and placement. B03 supplies reusable attacks. B04 composes the moves with placeholders while VFX/animation lanes proceed. B06 establishes durable outcomes before B05's phase restoration and A06's release integration. Final encounter acceptance integrates A01/A02/A08/A09/A10/A13 and the chain/column assembly. The dependency lists distinguish hard prerequisites from final presentation integration.

## Index

| ID | Draft issue | Hard prerequisites |
| --- | --- | --- |
| L01 | [Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md) | None |
| L02 | [Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md) | L01 |
| L03 | [Add bounded damage history and durable attribution](lubikan/l03-add-bounded-damage-history-and-durable-attribution.md) | None |
| L04 | [Implement Self charge activation and health regeneration](lubikan/l04-implement-self-charge-activation-and-health-regeneration.md) | L01, L02, L03 |
| L05 | [Add semantic cell occupancy and periodic charge rewards](lubikan/l05-add-semantic-cell-occupancy-and-periodic-charge-rewards.md) | L01, L02 |
| L06 | [Select inventory cycling categories with the D-pad](lubikan/l06-select-inventory-cycling-categories-with-the-d-pad.md) | L01 |
| L07 | [Display active Lubikan charge above player health](lubikan/l07-display-active-lubikan-charge-above-player-health.md) | L01, L02 |
| L08 | [Animate point feedback toward the credited Lubikan HUD](lubikan/l08-animate-point-feedback-toward-the-credited-lubikan-hud.md) | L02, L07 |
| L09 | [Ship the Self Lubikan gameplay loop independently](lubikan/l09-ship-the-self-lubikan-gameplay-loop-independently.md) | L04, L06, L07, L08 |
| B01 | [Add HCSG boss generation and Scripted authoring](boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md) | None |
| B02 | [Build Bikanwarda's encounter near the universal initial spawn](boss/b02-build-bikanwarda-s-encounter-near-the-universal-initial-spawn.md) | B01 |
| B03 | [Add reusable boss attack timing, hazards, and telegraphs](boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md) | None |
| B04 | [Implement Bikanwarda's Parade, God Beam, and Bray attacks](boss/b04-implement-bikanwarda-s-parade-god-beam-and-bray-attacks.md) | B03 |
| B05 | [Implement Bikanwarda's sleep, recovery, and waking phase](boss/b05-implement-bikanwarda-s-sleep-recovery-and-waking-phase.md) | B03, B06 |
| B06 | [Preserve Bikanwarda encounter outcomes and award summon unlocks](boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md) | B01, L01 |
| A01 | [Create reusable God Beam VFX](assets/a01-create-reusable-god-beam-vfx.md) | None |
| A02 | [Create reusable sonic-wave VFX](assets/a02-create-reusable-sonic-wave-vfx.md) | None |
| A03 | [Create a glowing mythical chain material with damage deterioration](assets/a03-create-a-glowing-mythical-chain-material-with-damage-deterioration.md) | None |
| A04 | [Generate runtime skinned rope and chain geometry](assets/a04-generate-runtime-skinned-rope-and-chain-geometry.md) | None |
| A05 | [Add anchored chain motion and capsule collision](assets/a05-add-anchored-chain-motion-and-capsule-collision.md) | A04 |
| A06 | [Make the mythical chain damageable and breakable](assets/a06-make-the-mythical-chain-damageable-and-breakable.md) | A05, B06 |
| A07 | [Create Bikanwarda's glowing skin tattoos](assets/a07-create-bikanwarda-s-glowing-skin-tattoos.md) | None |
| A08 | [Add per-character eye glow controls](assets/a08-add-per-character-eye-glow-controls.md) | None |
| A09 | [Author Epiphant Bray and sleep/wake clips](assets/a09-author-epiphant-bray-and-sleep-wake-clips.md) | None |
| A10 | [Add reusable spatial camera and ground rumble](assets/a10-add-reusable-spatial-camera-and-ground-rumble.md) | None |
| A11 | [Add a Doric column POM surface](assets/a11-add-a-doric-column-pom-surface.md) | None |
| A12 | [Create reusable Doric column and pedestal kits](assets/a12-create-reusable-doric-column-and-pedestal-kits.md) | None |
| A13 | [Assemble and validate the 20 m Bikanwarda character](assets/a13-assemble-and-validate-the-20-m-bikanwarda-character.md) | A07, A08, A09 |
| S01 | [Add Lubikan summon activation and owned lifecycle](summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md) | L01, L02 |
| S02 | [Implement Bikanwarda Lubikan affiliations and charge rules](summon/s02-implement-bikanwarda-lubikan-affiliations-and-charge-rules.md) | L02, L05 |
| S03 | [Implement Bikanwarda Ward and Enraged combat policies](summon/s03-implement-bikanwarda-ward-and-enraged-combat-policies.md) | S01, B03, B04 |
| S04 | [Add Bikanwarda's column, Ward strength boost, and glowing departure](summon/s04-add-bikanwarda-s-column-ward-strength-boost-and-glowing-departure.md) | S01, S03, A12, A13 |

## Open design decisions

Each owning issue records its unresolved behavior. The main decisions are:

1. Self activation cost/capacity/binding; interpretation of damage during healing.
2. Sleep repeatability, gradual versus final recovery, and early-wake recovery cancellation.
3. Beam width convention, targeting lock/tracking, cover blocking, and attack damage/cadence.
4. Whether lethal hits stack damage and kill awards; whether repeated hazard ticks each earn points.
5. Unlock exclusivity and encounter persistence across player death, streaming, sessions, and disk saves.
6. Summon duration/cost/concurrency, ownership and damage credit, Ward victim protection, and column lifetime.
7. Ward strength statistics/amount/stacking and forest-versus-grove occupancy granularity.

These are unresolved design inputs, not silently finalized requirements. Configurable defaults can support Self development without deciding Bikanwarda-specific rules.

## Publishing

Every issue body has a companion JSON manifest for the repository's [publish helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md). Suggested labels are feature and priority:high; adjust priorities before publication.

1. Publish the epics and record their actual issue numbers.
2. Set each child manifest's numeric parent to its published epic number. The manifests deliberately omit parent because no number exists yet.
3. Publish children and replace draft-relative dependency/parent links with their actual GitHub issue URLs. Relative links work in this extracted package; they are not valid cross-issue links when pasted into GitHub.
4. Replace each epic checklist with the published child URLs and associate the epics with the actual v0.1.4 release-candidate issue/milestone.

Run the helper from a Maybraid checkout with the manifest's path. Do not rerun a successfully published manifest to edit an existing issue; use the existing issue's edit operation.

## Files

- README.md: issue map, sequence, and publishing guidance.
- epics/: four parent issue drafts.
- lubikan/, boss/, assets/, summon/: individual implementation drafts and manifests.
- all-issues.md: the same full issue bodies collected for easy review.
