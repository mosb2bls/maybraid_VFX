# Maybraid v0.1.4 — Bikanwarda and Lubikan issue drafts

These are draft issue bodies for review and publication: **4 epics and 32 implementation issues**. They are grounded in [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). No issues have been published.

## Delivery structure

| Epic | Children | Delivery boundary |
| --- | --- | --- |
| [E01: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md) | 9 | Ship immediately through Self; no boss dependency. |
| [E02: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md) | 6 | Gameplay can develop against placeholder presentation. |
| [E03: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md) | 13 | Independent playground deliveries and final assembly. |
| [E04: Add Bikanwarda Ward and Enraged summons](epics/e04-summon-epic.md) | 4 | Extends Self framework; never blocks its release. |

## First shippable milestone: Self

Self is a real implementation of the Lubikan contract, not a placeholder for Bikanwarda. Deliver ordinary interaction points → Self charge → readiness → activation → healing with the charge HUD and flying-point feedback. The no-boss validation gate is L09.

- L01 establishes state and fallback.
- L02 supplies authoritative points/charge outcomes; L03 independently supplies damage history.
- L04 implements Self healing using L01–L03.
- L06 implements category selection/cycling; L07 supplies the HUD; L08 adds flying points.
- L05 supplies generic occupancy rewards in parallel and can be demonstrated with a configured Self rule.
- L09 integrates and verifies the independent playable loop. Its hard prerequisites do not include L05's full cell-rule delivery or any B/A/S issue.

## Boss and asset sequence

B01/B02 establish deterministic authored generation and placement. B03 supplies reusable attacks. B04 composes the moves with placeholders while VFX/animation lanes proceed. B06 establishes durable outcomes before B05's phase restoration and A06's release integration. Final encounter acceptance integrates A01/A02/A08/A09/A10/A13 and the chain/column assembly. The dependency lists distinguish hard prerequisites from final presentation integration.

## Index

| ID | Draft issue | Hard prerequisites |
| --- | --- | --- |
| L01 | [Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md) | None |
| L02 | [Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md) | L01 |
| L03 | [Add bounded damage history and durable attribution](lubikan/l03-add-bounded-damage-history-and-durable-attribution.md) | None |
| L04 | [Implement Self charge activation and health regeneration](lubikan/l04-implement-self-charge-activation-and-health-regeneration.md) | L01, L02, L03 |
| L05 | [Add semantic cell occupancy and periodic charge rewards](lubikan/l05-add-semantic-cell-occupancy-and-periodic-charge-rewards.md) | L01, L02 |
| L06 | [Select inventory cycling categories with the D-pad](lubikan/l06-select-inventory-cycling-categories-with-the-d-pad.md) | L01 |
| L07 | [Display active Lubikan charge above player health](lubikan/l07-display-active-lubikan-charge-above-player-health.md) | L01, L02 |
| L08 | [Animate point feedback toward the credited Lubikan HUD](lubikan/l08-animate-point-feedback-toward-the-credited-lubikan-hud.md) | L02, L07 |
| L09 | [Ship the Self Lubikan gameplay loop independently](lubikan/l09-ship-the-self-lubikan-gameplay-loop-independently.md) | L04, L06, L07, L08 |
| B01 | [Add HCSG boss generation and Scripted authoring](boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md) | None |
| B02 | [Build Bikanwarda's encounter near the universal initial spawn](boss/b02-build-bikanwarda-s-encounter-near-the-universal-initial-spawn.md) | B01 |
| B03 | [Add reusable boss attack timing, hazards, and telegraphs](boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md) | None |
| B04 | [Implement Bikanwarda's Parade, God Beam, and Bray attacks](boss/b04-implement-bikanwarda-s-parade-god-beam-and-bray-attacks.md) | B03 |
| B05 | [Implement Bikanwarda's sleep, recovery, and waking phase](boss/b05-implement-bikanwarda-s-sleep-recovery-and-waking-phase.md) | B03, B06 |
| B06 | [Preserve Bikanwarda encounter outcomes and award summon unlocks](boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md) | B01, L01 |
| A01 | [Create reusable God Beam VFX](assets/a01-create-reusable-god-beam-vfx.md) | None |
| A02 | [Create reusable sonic-wave VFX](assets/a02-create-reusable-sonic-wave-vfx.md) | None |
| A03 | [Create a glowing mythical chain material with damage deterioration](assets/a03-create-a-glowing-mythical-chain-material-with-damage-deterioration.md) | None |
| A04 | [Generate runtime skinned rope and chain geometry](assets/a04-generate-runtime-skinned-rope-and-chain-geometry.md) | None |
| A05 | [Add anchored chain motion and capsule collision](assets/a05-add-anchored-chain-motion-and-capsule-collision.md) | A04 |
| A06 | [Make the mythical chain damageable and breakable](assets/a06-make-the-mythical-chain-damageable-and-breakable.md) | A05, B06 |
| A07 | [Create Bikanwarda's glowing skin tattoos](assets/a07-create-bikanwarda-s-glowing-skin-tattoos.md) | None |
| A08 | [Add per-character eye glow controls](assets/a08-add-per-character-eye-glow-controls.md) | None |
| A09 | [Author Epiphant Bray and sleep/wake clips](assets/a09-author-epiphant-bray-and-sleep-wake-clips.md) | None |
| A10 | [Add reusable spatial camera and ground rumble](assets/a10-add-reusable-spatial-camera-and-ground-rumble.md) | None |
| A11 | [Add a Doric column POM surface](assets/a11-add-a-doric-column-pom-surface.md) | None |
| A12 | [Create reusable Doric column and pedestal kits](assets/a12-create-reusable-doric-column-and-pedestal-kits.md) | None |
| A13 | [Assemble and validate the 20 m Bikanwarda character](assets/a13-assemble-and-validate-the-20-m-bikanwarda-character.md) | A07, A08, A09 |
| S01 | [Add Lubikan summon activation and owned lifecycle](summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md) | L01, L02 |
| S02 | [Implement Bikanwarda Lubikan affiliations and charge rules](summon/s02-implement-bikanwarda-lubikan-affiliations-and-charge-rules.md) | L02, L05 |
| S03 | [Implement Bikanwarda Ward and Enraged combat policies](summon/s03-implement-bikanwarda-ward-and-enraged-combat-policies.md) | S01, B03, B04 |
| S04 | [Add Bikanwarda's column, Ward strength boost, and glowing departure](summon/s04-add-bikanwarda-s-column-ward-strength-boost-and-glowing-departure.md) | S01, S03, A12, A13 |

## Open design decisions

Each owning issue records its unresolved behavior. The main decisions are:

1. Self activation cost/capacity/binding; interpretation of damage during healing.
2. Sleep repeatability, gradual versus final recovery, and early-wake recovery cancellation.
3. Beam width convention, targeting lock/tracking, cover blocking, and attack damage/cadence.
4. Whether lethal hits stack damage and kill awards; whether repeated hazard ticks each earn points.
5. Unlock exclusivity and encounter persistence across player death, streaming, sessions, and disk saves.
6. Summon duration/cost/concurrency, ownership and damage credit, Ward victim protection, and column lifetime.
7. Ward strength statistics/amount/stacking and forest-versus-grove occupancy granularity.

These are unresolved design inputs, not silently finalized requirements. Configurable defaults can support Self development without deciding Bikanwarda-specific rules.

## Publishing

Every issue body has a companion JSON manifest for the repository's [publish helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md). Suggested labels are feature and priority:high; adjust priorities before publication.

1. Publish the epics and record their actual issue numbers.
2. Set each child manifest's numeric parent to its published epic number. The manifests deliberately omit parent because no number exists yet.
3. Publish children and replace draft-relative dependency/parent links with their actual GitHub issue URLs. Relative links work in this extracted package; they are not valid cross-issue links when pasted into GitHub.
4. Replace each epic checklist with the published child URLs and associate the epics with the actual v0.1.4 release-candidate issue/milestone.

Run the helper from a Maybraid checkout with the manifest's path. Do not rerun a successfully published manifest to edit an existing issue; use the existing issue's edit operation.

## Files

- README.md: issue map, sequence, and publishing guidance.
- epics/: four parent issue drafts.
- lubikan/, boss/, assets/, summon/: individual implementation drafts and manifests.
- all-issues.md: the same full issue bodies collected for easy review.


---

# lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md

# Summary

Introduce the reusable Lubikan model with Self as its first playable implementation, independently of Bikanwarda.

## Scope

- Represent definition identity, owned/unlocked entries, equipped selection, bounded charge, readiness, and activation state. Proposed names are design guidance, not fixed API requirements.
- Treat no equipped external Lubikan as Self through the same public model. Keep charge and activation state in gameplay; HUD availability must not affect it.
- Define charge ownership across equip/unequip, player-body replacement, and session restart. Keep each Lubikan's account distinct.
- Provide configurable Self capacity and activation cost so balancing does not block shipping the framework.

## Acceptance criteria

- [ ] A normal game with no boss content registers Self and exposes its charge/readiness.
- [ ] Positive and negative charge mutations clamp to valid limits; insufficient charge cannot activate.
- [ ] Switching selection does not transfer charge between accounts, duplicate ownership, or lose Self.
- [ ] Definition/state APIs can be consumed by future Lubikans without adding Bikanwarda dependencies.

## Validation

- Exercise account bounds, selection fallback, activation eligibility, and player replacement.
- Run the ordinary world with all Bikanwarda plugins/assets absent.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Self capacity, activation cost, and charge persistence after death require balance decisions; expose them as configuration.

## Relevant links

- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [World weapon/skill-map cycling and loadout synchronization](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/weapon.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md

# Summary

Route world interaction points into the active Lubikan's charge instead of calculating gameplay awards inside the combat HUD.

## Scope

- Consume applied combat outcomes and evaluate equipped-Lubikan rules for signed point changes, with an initial configurable Self policy.
- Emit an authoritative charge-change result carrying recipient, credited Lubikan identity, signed amount, reason, and optional world origin.
- Credit gameplay immediately; UI animations consume the result. Snapshot the credited selection at event resolution.
- Remove duplicate gameplay point accounting from CombatScore and hit-marker code. Retain mode statistics only where useful and define how their display relates to charge.

## Acceptance criteria

- [ ] Self earns charge through ordinary combat with no Bikanwarda installed.
- [ ] One resolved interaction produces one authoritative award; late readers and HUD visibility cannot duplicate or suppress it.
- [ ] Negative changes floor at zero and positive changes respect capacity.
- [ ] Point labels and the charge HUD consume actual rule outcomes rather than the old hardcoded hit/down values.

## Validation

- Exercise lethal hits, nonlethal hits, zero effective damage, unrelated attackers, and equip changes.
- Verify charge with HUD disabled and confirm existing training-mode statistics still behave intentionally.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Confirm whether hit and kill awards stack. For Self, keep reward weights configurable pending balance.
- DamageApplied.amount currently reflects the requested scaled amount rather than a measured HP delta; ensure zero/invalid hits and overkill cannot produce unintended awards.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Existing combat score ingestion](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/score.rs)
- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Damage-driven threat intelligence](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/damage/src/lib.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l03-add-bounded-damage-history-and-durable-attribution.md

# Summary

Maintain queryable recent damage history for gameplay lookback, including Self healing and future Lubikan affiliation rules.

## Scope

- Record accepted damage with game-time timestamp, recipient, effective amount, source, and identity/affiliation information needed after despawn.
- Use a bounded retention policy and query API by target and interval; avoid unbounded per-frame growth.
- Expose summon-owner attribution as an extension seam. Distinguish direct attacker from responsible owner.
- Define ordering with DamageSystems and lifecycle cleanup so events remain usable after a victim is retired.

## Acceptance criteria

- [ ] History answers whether a player took positive damage since a healing activation began.
- [ ] Expired records are removed and both time and capacity bounds are respected.
- [ ] Queries remain meaningful after source/victim entity despawn and do not match recycled entity identities.
- [ ] Damage history has no dependency on Lubikan visuals or Bikanwarda.

## Validation

- Exercise interval boundaries, multiple hits in one frame, source despawn, capacity overflow, and session reset.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Choose retention duration and overflow semantics; an active healing session must latch damage rather than rely forever on retained records.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l04-implement-self-charge-activation-and-health-regeneration.md

# Summary

Make the null Lubikan usable immediately by spending Self charge to activate the specified healing behavior.

## Scope

- Use the normal Lubikan activation path and a semantic activation intent with a configurable input binding.
- Heal 5% of maximum health per game-time second. With no damage during the activation, stop at 100%; after damage, cap continuing healing at 70%.
- Latch accepted positive damage during the session and terminate cleanly on death, invalid owner, or session teardown.
- Never reduce existing health to enforce a cap. Prevent duplicate concurrent healing sessions and undefined healing of a downed body.

## Acceptance criteria

- [ ] Self can be charged and activated in the normal world without any proper Lubikan.
- [ ] Healing is frame-rate independent and scales with maximum health.
- [ ] Damage during healing switches the cap to 70%; a player already above that cap receives no further healing and loses no health from the cap itself.
- [ ] Activation consumes charge according to the configured policy and exposes active/completed state to presentation.

## Validation

- Test undamaged healing to full, damaged healing to 70%, starting above 70%, lethal damage, pause, and player replacement.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [L03: Add bounded damage history and durable attribution](lubikan/l03-add-bounded-damage-history-and-durable-attribution.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Proposed interpretation: damage lowers the remainder's healing ceiling and does not cancel the whole event. Confirm before implementation.
- Choose the default activation binding and cost; no Bikanwarda work is required to make that choice.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Character gameplay intents](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/intent.rs)
- [Player health HUD](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/vitals.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l05-add-semantic-cell-occupancy-and-periodic-charge-rewards.md

# Summary

Provide an extensible enter/stay/exit system for awarding points from occupied generated cells.

## Scope

- Resolve the actor's semantic cell identity and expose occupancy changes plus periodic rule evaluation.
- Allow rules to match cell affiliation, forest/grove information, and construction presence; use spatial indexing and change-driven cached metadata.
- Emit awards through the shared charge pipeline; support a Self/demo rule so the system can be developed without Bikanwarda.
- Define timer ownership, re-entry behavior, overlapping matches, unloaded metadata, and pause semantics. Never infer semantic membership from rendered meshes.

## Acceptance criteria

- [ ] A configured occupancy rule can award Self charge on a timed interval.
- [ ] Leaving a qualifying region stops awards; repeated visual streaming cannot duplicate rewards.
- [ ] Several overlapping qualifying constructions do not multiply a single cell reward unless configured to do so.
- [ ] Rule extension requires no global vegetation scan each frame and no dependency on Bikanwarda.

## Validation

- Test enter/exit, exact interval boundaries, re-entry, overlapping cells/layers, large time steps, and absent metadata.
- Profile a stationary actor and cell transitions in a representative forest.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Specify whether 'forest cell with a construction' means any such construction anywhere in the forest cell or the actor's grove tile; keep matching granularity explicit.

## Relevant links

- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [Forest/grove generation and semantic presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/chico/src/hcsg.rs)
- [Semantic grove identity and recipes](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/chico/src/grove.rs)
- [Sope's Banyan construction](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/sbs-trees/src/sopes_banyan.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l06-select-inventory-cycling-categories-with-the-d-pad.md

# Summary

Use the D-pad to select which equipped inventory queue Y cycles, including Self and future Lubikans.

## Scope

- Right selects Weapons, Down Skill Maps, and Left Lubikans; Y cycles forward in the selected queue.
- Add Lubikan selection to the inventory/equipment model, with Self available even when no external Lubikan is owned.
- Remove gameplay D-pad map open/close and direct skill-map cycling. Keep Select/View as map toggle and retain intentional keyboard equivalents.
- Respect menu, text-input, map, and respawn-picker focus. Add a visible active-category cue and update control help.

## Acceptance criteria

- [ ] Weapons and skill maps cycle in the live world using category selection followed by Y.
- [ ] The Lubikan category works with a Self-only loadout; single-entry and empty queues are safe.
- [ ] Selecting a category does not itself cycle an item or activate a skill/summon.
- [ ] Select opens/closes the map and Tab continues its intended inventory behavior; UI navigation retains its own D-pad routing.

## Validation

- Exercise every category, queue wraparound, one-entry queues, held versus pressed input, keyboard bindings, and overlay/respawn focus.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Up remains unassigned in this proposal. Activation is a separate intent/binding, not Y cycling.

## Relevant links

- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [World weapon/skill-map cycling and loadout synchronization](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/weapon.rs)
- [Character gameplay intents](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/intent.rs)
- [Controller intent production](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/produce.rs)
- [World overhead map](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/map_view.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l07-display-active-lubikan-charge-above-player-health.md

# Summary

Add the Lubikan charge HUD with Self as a complete initial display.

## Scope

- Show active identity, current/capacity charge, activation eligibility, and active healing/summon state above player health.
- Implement a stable HUD destination anchor for flying points and a cue for the selected cycling category.
- Use authoritative model state and share gameplay/menu visibility rules with player vitals.
- Handle selection changes, charge loss, maximum charge, player respawn, and different viewport sizes.

## Acceptance criteria

- [ ] A Self-only game shows a complete usable charge display and healing state.
- [ ] Charge values match gameplay even when the HUD was hidden during awards.
- [ ] Readiness and negative changes are distinguishable; HUD construction never creates gameplay charge state.
- [ ] The display remains correctly positioned above health and does not require boss textures or portraits.

## Validation

- Visually verify normal, ready, healing, empty, hidden, and respawn states at several viewport sizes.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Relevant links

- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Player health HUD](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/vitals.rs)
- [Existing combat score ingestion](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/score.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l08-animate-point-feedback-toward-the-credited-lubikan-hud.md

# Summary

Animate awarded points from interaction locations to the charge display using authoritative charge-change results.

## Scope

- Project a supplied world origin to the HUD; provide sensible presentation for occupancy rewards and offscreen origins.
- Show signed values and distinguish gains from penalties; aggregate busy combat feedback within bounded UI work.
- Preserve the credited Lubikan identity if selection changes while feedback is travelling.
- Credit charge before animation starts; clear presentation safely when the HUD or player is retired.

## Acceptance criteria

- [ ] Combat and occupancy rewards fly toward Self's charge display with no Bikanwarda content.
- [ ] Displayed values match authoritative awards and do not affect accounting.
- [ ] Selection changes never visually credit the wrong account; hidden/offscreen cases fail gracefully.
- [ ] Point feedback remains bounded during multi-hit area attacks.

## Validation

- Visually check simultaneous awards, penalties, offscreen origins, HUD hiding, equip changes, and player death.

## Dependencies and delivery boundary

- [L02: Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [L07: Display active Lubikan charge above player health](lubikan/l07-display-active-lubikan-charge-above-player-health.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Relevant links

- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Existing combat score ingestion](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/score.rs)
- [Player health HUD](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/vitals.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# lubikan/l09-ship-the-self-lubikan-gameplay-loop-independently.md

# Summary

Integrate and validate points, charge, activation, healing, controls, and HUD as a standalone v0.1.4 delivery.

## Scope

- Wire general Lubikan plugins into ordinary gameplay with Self as the default.
- Deliver the complete loop: interaction → points → Self charge → readiness → activation → healing.
- Include periodic cell awards through a configurable demonstration rule; the generic rule framework can land separately from that content.
- Provide short gameplay documentation and a repeatable validation scenario. External Lubikan entries used in cycling tests may be fixtures.

## Acceptance criteria

- [ ] The normal world boots and the complete Self loop works with every Bikanwarda/encounter plugin disabled or absent.
- [ ] Weapon/skill-map category cycling and Select map access work with existing gameplay.
- [ ] Gameplay points are accounted for once, independently of HUD animation.
- [ ] Pause, death, replacement, and reset leave no stale healing session or HUD owner.

## Validation

- Run one focused integration scenario and manually verify the Self-only world.
- Exercise HUD-disabled accounting and rapid control/overlay changes.

## Dependencies and delivery boundary

- [L04: Implement Self charge activation and health regeneration](lubikan/l04-implement-self-charge-activation-and-health-regeneration.md)
- [L06: Select inventory cycling categories with the D-pad](lubikan/l06-select-inventory-cycling-categories-with-the-d-pad.md)
- [L07: Display active Lubikan charge above player health](lubikan/l07-display-active-lubikan-charge-above-player-health.md)
- [L08: Animate point feedback toward the credited Lubikan HUD](lubikan/l08-animate-point-feedback-toward-the-credited-lubikan-hud.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- This is an independent release gate, not a dependency on any boss, chain, column, or summon asset.

## Relevant links

- [World weapon/skill-map cycling and loadout synchronization](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/weapon.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Controller intent production](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/produce.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md

# Summary

Represent authored boss encounters through HCSG while leaving a compatible path for future generated bosses.

## Scope

- Define stable encounter/boss identity, bounds, ground dependency, actor recipe, attack configuration, and authored placement inputs.
- Establish a small Scripted<T> pattern for authored selection/configuration which feeds the shared boss model.
- Use GenerationContext for dependencies and HcsgNode/PresentationPlugin for presentation; generation remains a function of identity and session roots.
- Keep mutable health, chain durability, unlocks, and phase progress outside generated Arc values. Show the generated-boss extension seam without building a full procedural boss generator.

## Acceptance criteria

- [ ] Bikanwarda's authored definition generates deterministically from seeded inputs and ground.
- [ ] Discovery returns the encounter only for relevant regions; presentation is unique and cleans up its owned hosts.
- [ ] Scripted and future generated definitions can share runtime attacks and presentation.
- [ ] Rebuilding generated data does not itself decide encounter completion or unlock rewards.

## Validation

- Exercise identity/bounds, missing ground, presentation churn, and session restart.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Relevant links

- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [GenerationScheme and GenerationContext](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg/context.rs)
- [Barking mob generation/presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/barking/src/hcsg.rs)
- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# boss/b02-build-bikanwarda-s-encounter-near-the-universal-initial-spawn.md

# Summary

Place the chained 20 m Bikanwarda encounter near the universal initial spawn with a column and pedestal.

## Scope

- Resolve a shared initial-spawn/encounter anchor against the existing spawn policy, including first-spawn selection and explicit start positions.
- Assemble boss, column, pedestal, chain sockets, ground fit, and encounter bounds with enough room for attacks and movement.
- Declare how authored encounter ground shaping participates in terrain dependencies if needed; avoid post-spawn corrective geometry scans.
- Ensure boss position is tied to the intended world anchor rather than silently following every player respawn.

## Acceptance criteria

- [ ] The intended universal start has one accessible encounter near it.
- [ ] Boss, column, and chain are aligned to terrain and chain anchors remain coherent.
- [ ] Streaming across the encounter boundary does not spawn duplicates.
- [ ] Encounter remains testable with placeholder assets until final presentation lands.

## Validation

- Inspect the initial start and explicit-start configuration, uneven terrain, departure/re-entry, and restart.

## Dependencies and delivery boundary

- [B01: Add HCSG boss generation and Scripted authoring](boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Confirm the universal initial spawn anchor given the current first-spawn picker, desired distance, and whether the arena needs terrain flattening.

## Relevant links

- [Initial terrain player spawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/player/src/player.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Barking mob generation/presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/barking/src/hcsg.rs)
- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md

# Summary

Provide shared attack execution for authored encounters and summoned/generated bosses.

## Scope

- Represent windup, target snapshot/aim policy, execution, recovery, cooldown, and interruption.
- Separate authoritative hazard geometry/damage cadence from VFX; send damage through Hit.
- Own attack instances and effect handles so cancellation, death, sleep, and actor retirement clean up correctly.
- Support repeated area damage and moving wavefronts with explicit per-target hit policy; integrate targeting without fabricating visual contacts.

## Acceptance criteria

- [ ] An attack can run with placeholder or disabled VFX and still apply its specified damage.
- [ ] Each target is damaged at the configured cadence without duplicate collider hits.
- [ ] Attack cancellation removes active hazards and warning states.
- [ ] Encounter and summoned Bikanwarda can invoke the same attack definitions.

## Validation

- Exercise stage boundaries, interruption, multiple colliders per target, frame-rate variation, target loss, and owner despawn.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Default attack damage, cooldowns, interruption policy, and friendly-fire rules must be authored explicitly.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Blast overlap, falloff, and hit collection](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/items/grenades/src/lib.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Combat targeting](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/targeting.rs)
- [Independent target membership sources](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/source.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# boss/b04-implement-bikanwarda-s-parade-god-beam-and-bray-attacks.md

# Summary

Compose Bikanwarda's three moves using shared boss attack execution.

## Scope

- Parade of Explosions: warn with a line radiating toward the player, then sequence explosion hazards along it using existing fiery-explosion presentation.
- God Beam: warn with eye glow, then activate a 7 m laser column descending from the heavens for 10 seconds.
- Bray: play a head flick, emit sonic waves, and dispatch spatial rumble; synchronize any heavy landing impact with a separate impact cue.
- Author configuration for geometry, timing, damage, aiming, and recovery. Reuse attacks unchanged for summon forms apart from victim policy.

## Acceptance criteria

- [ ] Each warning predicts its actual hazard position and timing.
- [ ] Parade progression, ten-second beam lifetime, and Bray wave/animation timing are visible in a repeatable encounter.
- [ ] Sleep, death, and despawn stop appropriate attacks and clear eye glow.
- [ ] All attacks produce attributed Hit messages and obey configured ally/self victim policies.

## Validation

- Run each attack alone, then the encounter sequence; inspect warning cancellation and hit cadence with placeholder and final VFX.

## Dependencies and delivery boundary

- [B03: Add reusable boss attack timing, hazards, and telegraphs](boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Confirm beam diameter versus radius, target lock/tracking, obstruction by cover, Parade spacing/direction, Bray spread/range, and damage values.
- VFX/animation issues A01, A02, A09, A10, and A08 provide final presentation; placeholder attack execution can land first.

## Relevant links

- [Fiery explosion effect](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/effects/fiery_explosion.rs)
- [Blast overlap, falloff, and hit collection](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/items/grenades/src/lib.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Existing eye/face material](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/shaders/src/face_material.rs)
- [Quadruped animation implementation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/animations/src/rigs/quadruped.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# boss/b05-implement-bikanwarda-s-sleep-recovery-and-waking-phase.md

# Summary

Add Bikanwarda's health-triggered sleep/recovery behavior as explicit live encounter state.

## Scope

- Enter sleep when health crosses to 20% or lower while eligible; cancel incompatible attacks.
- Maintain a 15-second game-time sleep/recovery session intended to restore health to 50%.
- Support early waking when damage brings sleeping health to 10% or lower.
- Define death precedence, repeated threshold crossings, recovery on interruption, and presentation restoration through explicit states.

## Acceptance criteria

- [ ] 20% crossing enters sleep once for the configured phase policy.
- [ ] 15-second completion restores the agreed health amount and returns control.
- [ ] 10% crossing wakes her according to the agreed interruption policy; lethal damage cannot resurrect her.
- [ ] Phase state is not reconstructed from current health alone after streaming.

## Validation

- Test exact thresholds, a hit crossing both thresholds, death during sleep, heal/damage ordering, pause, and re-entry.

## Dependencies and delivery boundary

- [B03: Add reusable boss attack timing, hazards, and telegraphs](boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)
- [B06: Preserve Bikanwarda encounter outcomes and award summon unlocks](boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Blocking design decisions: one-time versus repeatable sleep; gradual regeneration versus end-of-sleep restoration; whether early wake cancels remaining recovery.
- Preserve these as explicit configuration/decisions rather than silently choosing a new combat rule.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Character motion integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/motion/README.md)
- [Parent draft: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md

# Summary

Track the chained encounter's durable state and resolve killing or freeing Bikanwarda into distinct Lubikan unlocks.

## Scope

- Key mutable encounter progress by stable encounter identity outside HCSG generated values.
- Track relevant live progress and terminal outcomes: killed unlocks Enraged, chain broken/free unlocks Ward.
- Resolve simultaneous kill/break signals deterministically and award each allowed unlock only once.
- Specify stream-out, player death, session reset, and save/load policy; presentation teardown is not a gameplay death or reward event.

## Acceptance criteria

- [ ] Killing Bikanwarda awards Enraged; freeing her through chain break awards Ward.
- [ ] Re-entering the area does not repair completed chains or recreate a completed encounter under the configured lifetime policy.
- [ ] Duplicate outcome messages do not duplicate inventory entries.
- [ ] Player/body replacement does not accidentally reset world encounter progress.

## Validation

- Test duplicate signals, same-frame kill/free, stream-out/re-entry, player death, and chosen persistence boundary.

## Dependencies and delivery boundary

- [B01: Add HCSG boss generation and Scripted authoring](boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md)
- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)

Authoritative gameplay may use placeholder presentation while final asset lanes proceed independently.

## Open decisions

- Decide whether unlocks are exclusive or both can eventually be earned and what she does immediately after release.
- Decide persistence across game restarts. If the repository lacks required save support, split its implementation as an explicit follow-up rather than claiming disk persistence.

## Relevant links

- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Build the scripted Bikanwarda boss encounter](epics/e02-boss-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a01-create-reusable-god-beam-vfx.md

# Summary

Create a parameterized heavenly laser column for Bikanwarda and future effects.

## Scope

- Provide beam width, origin/ground endpoint, palette, duration, seed, activation/fade, and cancellation controls through the existing VFX conventions.
- Compose a readable column core, surrounding energy, ground-contact effect, and arrival/departure cues.
- Keep hazard/damage behavior in attack gameplay. Support the Bikanwarda ten-second active phase and tall sky-facing presentation.
- Bound particle counts, light use, and transparent overdraw; add a playground preset.

## Acceptance criteria

- [ ] A 7 m configured column reads clearly at boss gameplay distances and remains active for ten seconds.
- [ ] Two independent instances do not mutate shared assets or timing.
- [ ] Cancellation and normal completion leave no particles/lights/hosts alive indefinitely.
- [ ] Effect integrates through the existing VFX API with documented parameters.

## Validation

- Inspect near/far views, ground intersections, simultaneous instances, cancellation, and sustained-frame performance.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Beam width convention is shared with B04 and must be documented.

## Relevant links

- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [VFX architecture and playground](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/README.md)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a02-create-reusable-sonic-wave-vfx.md

# Summary

Create propagating sonic-wave presentation for Bray without embedding combat behavior.

## Scope

- Expose emission transform/socket, speed, range, spread, wave count, lifetime, palette, and seed.
- Use particles and/or effect meshes that visibly communicate propagation and direction.
- Support cancellation and effect ownership through the existing VFX lifecycle.
- Keep gameplay hit geometry supplied by attack execution; add a playable preview preset.

## Acceptance criteria

- [ ] Waves visibly propagate from the intended emission point with configurable travel/spread.
- [ ] Presentation can match B04's authoritative wavefront timings.
- [ ] Repeated spawning and cancellation do not leak effect instances.
- [ ] Effect reads at the scale of a 20 m boss without obscuring the whole encounter.

## Validation

- Inspect moving emitters, near/far cameras, several palettes, overlapping waves, and cancellation.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [VFX architecture and playground](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/README.md)
- [Quadruped animation implementation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/animations/src/rigs/quadruped.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a03-create-a-glowing-mythical-chain-material-with-damage-deterioration.md

# Summary

Add a chain surface whose energy glow and deterioration are controlled by durability.

## Scope

- Expose intact/damage amount, glow palette/intensity, seed, and break/fade progress through a material recipe.
- Design deterioration that communicates weakening along the chain without requiring mesh regeneration for every hit.
- Preserve surface readability under the game's stylized lighting and the skinned chain's UV convention.
- Accept global durability initially; keep localized damage an explicit optional extension.

## Acceptance criteria

- [ ] The same chain renders distinct intact, damaged, near-breaking, and released states.
- [ ] Updating one chain does not alter every shared material instance.
- [ ] Glow and deterioration work while the mesh bends and remain legible at encounter distance.
- [ ] Material has a preview and documented parameter ranges.

## Validation

- Inspect durability sweep, animated deformation, day/night lighting, and two differently damaged chains.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Coordinate UVs and break representation with A04/A06; material previews can use a temporary mesh.

## Relevant links

- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [VFX architecture and playground](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/README.md)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a04-generate-runtime-skinned-rope-and-chain-geometry.md

# Summary

Generate one deformable chain mesh with a runtime-created armature and configurable segment count.

## Scope

- Generate mesh vertices, joint indices/weights, inverse bind poses, and joint entities from length, cross-section, and segment configuration.
- Accept a supplied chain pose/curve independently of the solver; use consistent segment/joint indexing.
- Cache compatible geometry/bind assets where practical; never rebuild them every frame.
- Expose anchors, UV distance convention, bounds updates, and limits on joints/segments. Keep the generic mechanism reusable for rope.

## Acceptance criteria

- [ ] Multiple lengths and segment counts produce one skinned mesh per chain and correct bind pose.
- [ ] Supplied bent poses deform smoothly without seam breaks, stretching discontinuities, or invalid normals.
- [ ] Bounds permit valid deformations to remain visible.
- [ ] Mesh generation has no dependency on Bikanwarda's rig or imported static armature.

## Validation

- Validate bind transforms/weights and inspect straight, bent, twisted, minimum, and longer configurations.
- Measure construction cost and steady pose update cost.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- A chain may use rigidly weighted link geometry inside the single mesh; confirm desired linked-chain versus continuous-energy-rope appearance.

## Relevant links

- [Existing character skin remapping](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/skin.rs)
- [Quadruped rig](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/rigs/src/rigs/quadruped_v0.rs)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a05-add-anchored-chain-motion-and-capsule-collision.md

# Summary

Drive chain joints and capsule colliders from a consistent anchored chain pose.

## Scope

- Represent column/body endpoints and chain length; resolve character socket attachment through normal assembly.
- Choose and document a bounded chain-motion approach, including tension/restraint behavior.
- Update the skinned pose and capsule transforms from one authoritative segment state.
- Separate chain skinning from simulation; permit a simple prescribed pose mode for previews and tests.

## Acceptance criteria

- [ ] The chain follows Bikanwarda and the column without detached endpoints.
- [ ] Capsules remain aligned to rendered segments and expose a stable damage target.
- [ ] The chained boss respects the agreed reach/restraint policy.
- [ ] Release and owner retirement remove restraint and retire owned colliders/joints.

## Validation

- Exercise boss movement/rotation, terrain contact, stretched endpoints, pause, chain release, and teardown.

## Dependencies and delivery boundary

- [A04: Generate runtime skinned rope and chain geometry](assets/a04-generate-runtime-skinned-rope-and-chain-geometry.md)

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Decide whether restraint is gameplay kinematics, constraint simulation, or full physical joints; do not treat runtime armature creation as that decision.

## Relevant links

- [Existing character skin remapping](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/skin.rs)
- [Quadruped rig](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/rigs/src/rigs/quadruped_v0.rs)
- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a06-make-the-mythical-chain-damageable-and-breakable.md

# Summary

Connect chain capsule hits to durability and a one-shot release outcome.

## Scope

- Route child-collider hits to the intended chain health/durability target using the existing damage seam.
- Drive material deterioration from durability and emit a typed chain-broken signal at zero.
- Detach restraint/anchors and perform the agreed visual break behavior.
- Keep chain destruction distinct from boss death; report encounter release through B06.

## Acceptance criteria

- [ ] Attacking any configured chain capsule damages the correct chain.
- [ ] One physical interaction cannot multiply damage through overlapping capsules.
- [ ] Zero durability breaks once and frees Bikanwarda without killing her.
- [ ] Visual state and collision/restraint cleanup follow the same broken outcome.

## Validation

- Test child hit resolution, overlapping capsules, lethal chain hit, duplicate signals, simultaneous boss death, and streaming.

## Dependencies and delivery boundary

- [A05: Add anchored chain motion and capsule collision](assets/a05-add-anchored-chain-motion-and-capsule-collision.md)
- [B06: Preserve Bikanwarda encounter outcomes and award summon unlocks](boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md)

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Final material A03 can integrate later. Decide whether break is whole-chain dissolution, a localized gap, or severed pieces; one-mesh rendering does not itself define severing.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a07-create-bikanwarda-s-glowing-skin-tattoos.md

# Summary

Author tattoo markings and controllable emission for Bikanwarda's skinned body.

## Scope

- Create an authored tattoo mask/design and material recipe compatible with Epiphant body/head UVs or a documented alternative mapping.
- Expose color, intensity, and optional pulse parameters while preserving existing skin shading.
- Apply materials at the normal part-host ownership points; do not introduce a global post-spawn repaint scan.
- Document source assets, mapping, and how future boss variants recolor/reuse the effect.

## Acceptance criteria

- [ ] Tattoo markings follow the skinned character through idle, movement, and Bray.
- [ ] Glow is controllable per character and behaves under day/night lighting.
- [ ] Seams and mirrored parts are intentional and do not show obvious mapping breaks.
- [ ] Source assets and recipe are reproducible through the normal asset workflow.

## Validation

- Inspect the actual Epiphant mesh/UVs and posed model, then verify close and encounter-distance appearance.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Character assembly and material/animation ownership](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/CONTRIBUTING.md)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a08-add-per-character-eye-glow-controls.md

# Summary

Extend eye presentation with a reliable runtime warning glow for God Beam.

## Scope

- Add per-character emission intensity/color and optional transition duration to the existing face-eye material path.
- Expose controls through the normal character part/material ownership mechanism.
- Support warning on/off, interruption reset, and ordinary eye appearance at zero glow.
- Keep the control generic and independent of Bikanwarda's combat code.

## Acceptance criteria

- [ ] One character's eye warning does not change other characters.
- [ ] Turning glow off restores normal eyes without rebuilding the character.
- [ ] God Beam warning can start/cancel/reset through a documented control.
- [ ] The effect remains readable at intended boss distance.

## Validation

- Preview off/on/transition states on Epiphant and another supported character; inspect material sharing and repeated toggles.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Existing eye/face material](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/shaders/src/face_material.rs)
- [Character assembly and material/animation ownership](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/CONTRIBUTING.md)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a09-author-epiphant-bray-and-sleep-wake-clips.md

# Summary

Add rig-correct animations for Bikanwarda's head-flick Bray and sleep phase.

## Scope

- Inspect the Epiphant GLB and armature dump directly before choosing articulation axes.
- Author Bray anticipation, head flick, and recovery plus sleep entry, held sleep, and wake.
- Integrate with existing clip identity, sampling/cache, and motion mailbox conventions.
- Expose or document timing cues for sonic emission and any heavy landing impact; gameplay consumes cues without being implemented inside pose sampling.

## Acceptance criteria

- [ ] Bray visibly flicks the head using the actual Epiphant rig and transitions naturally to idle.
- [ ] Sleep/wake can be interrupted by gameplay phase changes without a stuck pose.
- [ ] Wave/impact timing is repeatable and aligns with attack execution.
- [ ] Existing quadruped walk/run and character pose behavior remain usable.

## Validation

- Preview on the actual Epiphant at ordinary and boss scale, inspect bone axes, transitions, and interrupted sleep/Bray.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Quadruped animation implementation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/animations/src/rigs/quadruped.rs)
- [Quadruped rig](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/rigs/src/rigs/quadruped_v0.rs)
- [Character motion integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/motion/README.md)
- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a10-add-reusable-spatial-camera-and-ground-rumble.md

# Summary

Create a general effects crate/API for spatial rumble from sonic attacks and heavy impacts.

## Scope

- Expose source position, range/falloff, intensity, duration/envelope, seed, and channels.
- Adapt to camera shake and existing PadRumble; provide ground feedback as a separate supported presentation channel.
- Compose concurrent sources with bounded output and apply camera shake without accumulating drift or changing locomotion.
- Provide intensity controls and cleanup when camera/player ownership changes; gameplay hazards remain independent.

## Acceptance criteria

- [ ] A dispatched effect produces distance-scaled camera/ground feedback and optional controller vibration.
- [ ] Bray and heavy landing can use the same API with different presets.
- [ ] Overlapping effects have predictable bounded output and finish without residual camera displacement.
- [ ] Keyboard/mouse play works without a connected controller.

## Validation

- Check stationary/moving camera, POV changes, simultaneous effects, distance falloff, pause, and owner replacement.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Specify whether ground feedback is dust/rings/material motion or actual ground displacement; prefer an explicit channel contract before implementing it.

## Relevant links

- [Existing controller rumble message](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/input/src/rumble.rs)
- [Player camera integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/player-camera/src/lib.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a11-add-a-doric-column-pom-surface.md

# Summary

Extend architectural materials with stylized Doric fluting and column surface relief.

## Scope

- Use the existing urban POM/material conventions where suitable, with cylindrical mapping or a documented column UV convention.
- Author height/normal/color response for fluting; include quality bounds and distance/angle fading.
- Keep shaft outline, capital, pedestal, and cover collision in real geometry.
- Provide a column material preview that can be integrated into reusable kits.

## Acceptance criteria

- [ ] Fluting reads as relief from representative viewing angles and blends cleanly into distant shading.
- [ ] UV seam and curved-surface grazing views do not show major discontinuities.
- [ ] Material does not change collision or claim POM produces the physical cover shape.
- [ ] Sampling work is bounded and configurable for a large visible column.

## Validation

- Inspect orbiting views, close/grazing/distant shots, day/night lighting, and shader performance.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Existing urban POM surface shader](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/shaders/src/urban_surface.wgsl)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Building component/kit library](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/components/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a12-create-reusable-doric-column-and-pedestal-kits.md

# Summary

Create the architectural assembly used by Bikanwarda's encounter and summons.

## Scope

- Provide column shaft, capital, pedestal, configurable dimensions/material assignments, and chain attachment anchors.
- Use existing kit/component assembly conventions and stable transforms.
- Add appropriate physical cover colliders and terrain placement contract.
- Keep architectural assets independent of boss AI and Lubikan charge logic.

## Acceptance criteria

- [ ] An encounter and a runtime summon can instantiate the same column/pedestal assembly.
- [ ] The column blocks movement and participates in cover queries as intended.
- [ ] Anchors match the visual kit and support chain attachment.
- [ ] Scaling and material replacement do not misalign colliders or kit parts.

## Validation

- Inspect assembly dimensions, chain anchors, terrain fit, collisions, sight/trajectory cover, and repeated spawning.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- POM A11 enhances the final material; geometry/collision can land first. Decide summoned-column durability and departure lifetime with S04.

## Relevant links

- [Building component/kit library](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/components/src/lib.rs)
- [Existing urban POM surface shader](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/shaders/src/urban_surface.wgsl)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# assets/a13-assemble-and-validate-the-20-m-bikanwarda-character.md

# Summary

Create Bikanwarda's final authored Epiphant presentation and physical dimensions.

## Scope

- Build from EpiphantConfig/character recipe with authored proportions, 20 m standing height, materials, eyes, and tattoos.
- Configure collision, sockets/emission positions, chain anchor, health-bar position, visual bounds, and visibility/LOD policy for a large actor.
- Integrate Bray and sleep/wake clips without duplicating character assembly or motion systems.
- Deliver a preview suitable for encounter and summon forms with parameterized form presentation.

## Acceptance criteria

- [ ] The assembled character is 20 m tall under the documented standing-height measurement.
- [ ] Collision and attack/chain sockets match the visual body at boss scale.
- [ ] Animated bounds and HUD anchors remain valid in Bray and sleep poses.
- [ ] Encounter, Ward, and Enraged can use the same authored actor recipe.

## Validation

- Inspect close/normal/far views, occlusion and LOD transitions, animation extremes, collider fit, and two instances.

## Dependencies and delivery boundary

- [A07: Create Bikanwarda's glowing skin tattoos](assets/a07-create-bikanwarda-s-glowing-skin-tattoos.md)
- [A08: Add per-character eye glow controls](assets/a08-add-per-character-eye-glow-controls.md)
- [A09: Author Epiphant Bray and sleep/wake clips](assets/a09-author-epiphant-bray-and-sleep-wake-clips.md)

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Confirm height measurement excludes accessories and whether summons share the full encounter scale.

## Relevant links

- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Character assembly and material/animation ownership](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/CONTRIBUTING.md)
- [Existing character skin remapping](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/skin.rs)
- [Character motion integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/motion/README.md)
- [Parent draft: Build reusable Bikanwarda assets and effects](epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md

# Summary

Extend the independent Lubikan framework with reusable summon activation, placement, and teardown.

## Scope

- Consume charge through the normal activation contract; define owner, instance identity, lifetime, concurrent limits, and invalid-placement behavior.
- Spawn an actor from a Lubikan-supplied recipe and preserve owner attribution for damage/charge rules.
- Keep active summon ownership independent of changing the equipped selection and define dismissal policy.
- Clean up active attacks, modifiers, effects, and auxiliary structures through a typed departure path.

## Acceptance criteria

- [ ] A minimal fixture summon can activate without the full Bikanwarda encounter.
- [ ] Invalid activation cannot lose charge or spawn partial orphaned content under the agreed transactional policy.
- [ ] Owner death/replacement, timeout, and world reset retire all owned state.
- [ ] Normal departure is distinct from Died and does not emit kill rewards.

## Validation

- Exercise charge spend, placement rejection, rapid activation, limit enforcement, owner retirement, and interrupted departure.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Decide activation cost, duration, concurrent summon count, dismissal/equip behavior, and charge attribution for summon-caused damage. These do not block Self delivery.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# summon/s02-implement-bikanwarda-lubikan-affiliations-and-charge-rules.md

# Summary

Configure Bikanwarda charge gains/losses from animal/raider interactions and Sope's Banyan forest occupancy.

## Scope

- Match animal herds/packs as affiliated groups and raiders as opposed groups using semantic affiliation information.
- Apply animal damage −5 and kill −10; raider damage +5 and kill +25; clamp charge at zero/capacity.
- Apply +5 every five seconds in a qualifying forest cell containing a Sope's Banyan construction.
- Keep weights/predicates in Bikanwarda's definition/configuration rather than generic damage, HUD, or forest code.

## Acceptance criteria

- [ ] The specified weights apply to the equipped Bikanwarda account.
- [ ] Animal and raider identity remains usable when the victim is retired.
- [ ] Forest reward cadence does not depend on rendered tree entities.
- [ ] Neither rule registration nor Bikanwarda content is required for Self charge/healing.

## Validation

- Use semantic fixtures and a generated forest to verify gains/losses, lethal-hit policy, interval cadence, and selection changes.

## Dependencies and delivery boundary

- [L02: Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [L05: Add semantic cell occupancy and periodic charge rewards](lubikan/l05-add-semantic-cell-occupancy-and-periodic-charge-rewards.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Confirm whether these rules are identical for Ward and Enraged and whether lethal hits stack damage plus kill awards.
- Decide per-hit/tick versus per-attack treatment; persistent beam ticks otherwise create much faster charge gains.

## Relevant links

- [Directional affiliations](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/src/affiliation.rs)
- [Barking mob generation/presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/barking/src/hcsg.rs)
- [Sope's Banyan construction](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/sbs-trees/src/sopes_banyan.rs)
- [Forest/grove generation and semantic presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/chico/src/hcsg.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# summon/s03-implement-bikanwarda-ward-and-enraged-combat-policies.md

# Summary

Reuse Bikanwarda's attacks with form-specific target and victim policies.

## Scope

- Ward selects the summoner's enemies; Enraged may target anyone including its summoner.
- Feed existing affiliation/targeting sources and real contact knowledge; avoid a second global enemy list or fabricated sightings.
- Apply victim filtering to area damage separately from selecting an intended target.
- Reuse Parade, God Beam, and Bray timing/configuration; give each form inspectable policy state.

## Acceptance criteria

- [ ] Ward attacks the owner's enemies and does not damage the protected owner/allies under the agreed policy.
- [ ] Enraged can select and damage its summoner as well as other combatants.
- [ ] Both forms execute the same three attacks as the encounter.
- [ ] Target retirement, missing contact, and owner change are handled without stale target access.

## Validation

- Run mixed owner/ally/raider/animal scenes; verify both target choice and actual area damage, including owner inside the beam/blast.

## Dependencies and delivery boundary

- [S01: Add Lubikan summon activation and owned lifecycle](summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md)
- [B03: Add reusable boss attack timing, hazards, and telegraphs](boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)
- [B04: Implement Bikanwarda's Parade, God Beam, and Bray attacks](boss/b04-implement-bikanwarda-s-parade-god-beam-and-bray-attacks.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Confirm whether Ward's area effects are fully ally-safe and what qualifies as 'your enemies' when affiliation and recent antagonism differ.

## Relevant links

- [Directional affiliations](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/src/affiliation.rs)
- [Combat targeting](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/targeting.rs)
- [Independent target membership sources](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/source.rs)
- [Damage-driven threat intelligence](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/damage/src/lib.rs)
- [Blast overlap, falloff, and hit collection](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/items/grenades/src/lib.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# summon/s04-add-bikanwarda-s-column-ward-strength-boost-and-glowing-departure.md

# Summary

Complete Bikanwarda's summon-specific cover, buff, and non-death departure behavior.

## Scope

- Spawn her column with the summon using the shared architectural kit and validate both placements.
- Apply Ward's owned strength modifier to the intended beneficiary; remove only that modifier when the summon ends.
- Fade Bikanwarda out with glow through summon departure; stop hazards and targeting at the defined departure point.
- Define column lifetime/collision behavior during and after the fade and guarantee auxiliary cleanup.

## Acceptance criteria

- [ ] Bikanwarda arrives with a physical cover column.
- [ ] Ward boosts the agreed strength statistics and Enraged does not accidentally inherit that benefit.
- [ ] Normal departure fades/glows, emits no kill/unlock reward, and leaves no buff/hazard orphan.
- [ ] Repeated summons never stack stale buffs or leave columns beyond their configured lifetime.

## Validation

- Inspect arrival/departure, owner death, mid-attack timeout, repeated summons, buff interactions, and column cover.

## Dependencies and delivery boundary

- [S01: Add Lubikan summon activation and owned lifecycle](summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md)
- [S03: Implement Bikanwarda Ward and Enraged combat policies](summon/s03-implement-bikanwarda-ward-and-enraged-combat-policies.md)
- [A12: Create reusable Doric column and pedestal kits](assets/a12-create-reusable-doric-column-and-pedestal-kits.md)
- [A13: Assemble and validate the 20 m Bikanwarda character](assets/a13-assemble-and-validate-the-20-m-bikanwarda-character.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Define strength statistic(s), multiplier/addition, beneficiary, stacking, and duration.
- Decide whether the column departs with her or persists as cover; final fade art can follow a working lifecycle.

## Relevant links

- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Building component/kit library](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/components/src/lib.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._


---

# epics/e01-lubikan-epic.md

# Summary

Ship a complete Lubikan gameplay loop through Self, the null/default Lubikan, before Bikanwarda is available. Points, charge, activation, healing, inventory category selection, and HUD feedback are immediately usable general gameplay.

## Independent release gate

The first production Lubikan is Self. L09 demonstrates the full loop with no Bikanwarda plugins or assets. Do not defer charge, HUD, points, healing, or cycling until a proper summon exists. Cell rewards are an independently extensible lane and can be demonstrated with a configured Self rule.

## Child issues

- [ ] [L01: Introduce equipped Lubikans, charge state, and the Self fallback](lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [ ] [L02: Move gameplay points into equipped Lubikan charge rules](lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [ ] [L03: Add bounded damage history and durable attribution](lubikan/l03-add-bounded-damage-history-and-durable-attribution.md)
- [ ] [L04: Implement Self charge activation and health regeneration](lubikan/l04-implement-self-charge-activation-and-health-regeneration.md)
- [ ] [L05: Add semantic cell occupancy and periodic charge rewards](lubikan/l05-add-semantic-cell-occupancy-and-periodic-charge-rewards.md)
- [ ] [L06: Select inventory cycling categories with the D-pad](lubikan/l06-select-inventory-cycling-categories-with-the-d-pad.md)
- [ ] [L07: Display active Lubikan charge above player health](lubikan/l07-display-active-lubikan-charge-above-player-health.md)
- [ ] [L08: Animate point feedback toward the credited Lubikan HUD](lubikan/l08-animate-point-feedback-toward-the-credited-lubikan-hud.md)
- [ ] [L09: Ship the Self Lubikan gameplay loop independently](lubikan/l09-ship-the-self-lubikan-gameplay-loop-independently.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.
- [ ] Self-only gameplay ships independently with the entire Bikanwarda content stack absent.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)


---

# epics/e02-boss-epic.md

# Summary

Build Bikanwarda as an authored 20 m Epiphant encounter near the universal initial spawn, chained to a column, with reusable attacks, sleep/recovery, and kill/free outcomes.

## Required encounter behavior

- Parade of Explosions: warned line toward the player followed by advancing explosions.
- God Beam: eye-glow warning followed by a 7 m heavenly column active for 10 seconds.
- Bray: head flick followed by sonic waves and rumble.
- Sleep at 20% health for 15 seconds and recover to 50%; wake early if sleeping health reaches 10%. Recovery/interruption details remain explicit open decisions in B05.
- Kill unlocks Enraged; breaking the chain/freeing her unlocks Ward.

## Child issues

- [ ] [B01: Add HCSG boss generation and Scripted authoring](boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md)
- [ ] [B02: Build Bikanwarda's encounter near the universal initial spawn](boss/b02-build-bikanwarda-s-encounter-near-the-universal-initial-spawn.md)
- [ ] [B03: Add reusable boss attack timing, hazards, and telegraphs](boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)
- [ ] [B04: Implement Bikanwarda's Parade, God Beam, and Bray attacks](boss/b04-implement-bikanwarda-s-parade-god-beam-and-bray-attacks.md)
- [ ] [B05: Implement Bikanwarda's sleep, recovery, and waking phase](boss/b05-implement-bikanwarda-s-sleep-recovery-and-waking-phase.md)
- [ ] [B06: Preserve Bikanwarda encounter outcomes and award summon unlocks](boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)


---

# epics/e03-assets-epic.md

# Summary

Deliver independent reusable visual/physical assets for Bikanwarda, using existing VFX, materials, character assembly, architectural kits, and rumble foundations.

## Parallel asset delivery

Effects/materials should have standalone playground presets. Runtime chain skinning and chain motion are separate contracts. Architectural geometry owns silhouette and physical cover; POM owns surface relief. Final assembly validates the combined 20 m character.

## Child issues

- [ ] [A01: Create reusable God Beam VFX](assets/a01-create-reusable-god-beam-vfx.md)
- [ ] [A02: Create reusable sonic-wave VFX](assets/a02-create-reusable-sonic-wave-vfx.md)
- [ ] [A03: Create a glowing mythical chain material with damage deterioration](assets/a03-create-a-glowing-mythical-chain-material-with-damage-deterioration.md)
- [ ] [A04: Generate runtime skinned rope and chain geometry](assets/a04-generate-runtime-skinned-rope-and-chain-geometry.md)
- [ ] [A05: Add anchored chain motion and capsule collision](assets/a05-add-anchored-chain-motion-and-capsule-collision.md)
- [ ] [A06: Make the mythical chain damageable and breakable](assets/a06-make-the-mythical-chain-damageable-and-breakable.md)
- [ ] [A07: Create Bikanwarda's glowing skin tattoos](assets/a07-create-bikanwarda-s-glowing-skin-tattoos.md)
- [ ] [A08: Add per-character eye glow controls](assets/a08-add-per-character-eye-glow-controls.md)
- [ ] [A09: Author Epiphant Bray and sleep/wake clips](assets/a09-author-epiphant-bray-and-sleep-wake-clips.md)
- [ ] [A10: Add reusable spatial camera and ground rumble](assets/a10-add-reusable-spatial-camera-and-ground-rumble.md)
- [ ] [A11: Add a Doric column POM surface](assets/a11-add-a-doric-column-pom-surface.md)
- [ ] [A12: Create reusable Doric column and pedestal kits](assets/a12-create-reusable-doric-column-and-pedestal-kits.md)
- [ ] [A13: Assemble and validate the 20 m Bikanwarda character](assets/a13-assemble-and-validate-the-20-m-bikanwarda-character.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)


---

# epics/e04-summon-epic.md

# Summary

Extend the already-shippable Lubikan framework with Bikanwarda's Ward and Enraged forms, shared boss attacks, affiliation rewards, cover column, Ward buff, and glowing departure.

## Required form behavior

- Both forms reuse encounter attacks.
- Enraged attacks anything, including the summoner.
- Ward attacks the summoner's enemies and boosts strength.
- Both spawn with a physical cover column and depart through glow/fade rather than ordinary death.
- Animal damage/kill: −5/−10 charge. Raider damage/kill: +5/+25. Qualifying Sope's Banyan forest occupancy: +5 per five seconds.

## Child issues

- [ ] [S01: Add Lubikan summon activation and owned lifecycle](summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md)
- [ ] [S02: Implement Bikanwarda Lubikan affiliations and charge rules](summon/s02-implement-bikanwarda-lubikan-affiliations-and-charge-rules.md)
- [ ] [S03: Implement Bikanwarda Ward and Enraged combat policies](summon/s03-implement-bikanwarda-ward-and-enraged-combat-policies.md)
- [ ] [S04: Add Bikanwarda's column, Ward strength boost, and glowing departure](summon/s04-add-bikanwarda-s-column-ward-strength-boost-and-glowing-departure.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)
