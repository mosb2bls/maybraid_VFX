# Summary

Complete Bikanwarda's summon-specific cover, buff, and non-death departure behavior.

## Scope

- Spawn her column with the summon using the shared architectural kit and validate both placements.
- Apply Ward's owned strength modifier to the intended beneficiary; remove only that modifier when the summon ends.
- Fade Bikanwarda out with glow through summon departure; stop hazards and targeting at the defined departure point.
- Define column lifetime/collision behavior during and after the fade and guarantee auxiliary cleanup.

## Acceptance criteria

- [ ] Bikanwarda arrives with a physical cover column.
- [ ] Ward boosts the agreed strength statistics and Enraged does not accidentally inherit that benefit.
- [ ] Normal departure fades/glows, emits no kill/unlock reward, and leaves no buff/hazard orphan.
- [ ] Repeated summons never stack stale buffs or leave columns beyond their configured lifetime.

## Validation

- Inspect arrival/departure, owner death, mid-attack timeout, repeated summons, buff interactions, and column cover.

## Dependencies and delivery boundary

- [S01: Add Lubikan summon activation and owned lifecycle](../summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md)
- [S03: Implement Bikanwarda Ward and Enraged combat policies](../summon/s03-implement-bikanwarda-ward-and-enraged-combat-policies.md)
- [A12: Create reusable Doric column and pedestal kits](../assets/a12-create-reusable-doric-column-and-pedestal-kits.md)
- [A13: Assemble and validate the 20 m Bikanwarda character](../assets/a13-assemble-and-validate-the-20-m-bikanwarda-character.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Define strength statistic(s), multiplier/addition, beneficiary, stacking, and duration.
- Decide whether the column departs with her or persists as cover; final fade art can follow a working lifecycle.

## Relevant links

- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Building component/kit library](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/components/src/lib.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](../epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
