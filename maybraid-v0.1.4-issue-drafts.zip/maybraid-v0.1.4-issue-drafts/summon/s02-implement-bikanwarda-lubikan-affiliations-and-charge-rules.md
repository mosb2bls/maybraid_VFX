# Summary

Configure Bikanwarda charge gains/losses from animal/raider interactions and Sope's Banyan forest occupancy.

## Scope

- Match animal herds/packs as affiliated groups and raiders as opposed groups using semantic affiliation information.
- Apply animal damage −5 and kill −10; raider damage +5 and kill +25; clamp charge at zero/capacity.
- Apply +5 every five seconds in a qualifying forest cell containing a Sope's Banyan construction.
- Keep weights/predicates in Bikanwarda's definition/configuration rather than generic damage, HUD, or forest code.

## Acceptance criteria

- [ ] The specified weights apply to the equipped Bikanwarda account.
- [ ] Animal and raider identity remains usable when the victim is retired.
- [ ] Forest reward cadence does not depend on rendered tree entities.
- [ ] Neither rule registration nor Bikanwarda content is required for Self charge/healing.

## Validation

- Use semantic fixtures and a generated forest to verify gains/losses, lethal-hit policy, interval cadence, and selection changes.

## Dependencies and delivery boundary

- [L02: Move gameplay points into equipped Lubikan charge rules](../lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [L05: Add semantic cell occupancy and periodic charge rewards](../lubikan/l05-add-semantic-cell-occupancy-and-periodic-charge-rewards.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Confirm whether these rules are identical for Ward and Enraged and whether lethal hits stack damage plus kill awards.
- Decide per-hit/tick versus per-attack treatment; persistent beam ticks otherwise create much faster charge gains.

## Relevant links

- [Directional affiliations](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/src/affiliation.rs)
- [Barking mob generation/presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/barking/src/hcsg.rs)
- [Sope's Banyan construction](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/sbs-trees/src/sopes_banyan.rs)
- [Forest/grove generation and semantic presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/chico/src/hcsg.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](../epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
