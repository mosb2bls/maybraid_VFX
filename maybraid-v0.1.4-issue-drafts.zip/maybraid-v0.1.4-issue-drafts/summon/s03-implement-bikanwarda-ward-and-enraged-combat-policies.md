# Summary

Reuse Bikanwarda's attacks with form-specific target and victim policies.

## Scope

- Ward selects the summoner's enemies; Enraged may target anyone including its summoner.
- Feed existing affiliation/targeting sources and real contact knowledge; avoid a second global enemy list or fabricated sightings.
- Apply victim filtering to area damage separately from selecting an intended target.
- Reuse Parade, God Beam, and Bray timing/configuration; give each form inspectable policy state.

## Acceptance criteria

- [ ] Ward attacks the owner's enemies and does not damage the protected owner/allies under the agreed policy.
- [ ] Enraged can select and damage its summoner as well as other combatants.
- [ ] Both forms execute the same three attacks as the encounter.
- [ ] Target retirement, missing contact, and owner change are handled without stale target access.

## Validation

- Run mixed owner/ally/raider/animal scenes; verify both target choice and actual area damage, including owner inside the beam/blast.

## Dependencies and delivery boundary

- [S01: Add Lubikan summon activation and owned lifecycle](../summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md)
- [B03: Add reusable boss attack timing, hazards, and telegraphs](../boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)
- [B04: Implement Bikanwarda's Parade, God Beam, and Bray attacks](../boss/b04-implement-bikanwarda-s-parade-god-beam-and-bray-attacks.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Confirm whether Ward's area effects are fully ally-safe and what qualifies as 'your enemies' when affiliation and recent antagonism differ.

## Relevant links

- [Directional affiliations](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/src/affiliation.rs)
- [Combat targeting](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/targeting.rs)
- [Independent target membership sources](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/combat/targeting/src/source.rs)
- [Damage-driven threat intelligence](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/damage/src/lib.rs)
- [Blast overlap, falloff, and hit collection](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/items/grenades/src/lib.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](../epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
