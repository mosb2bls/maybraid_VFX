# Summary

Extend the independent Lubikan framework with reusable summon activation, placement, and teardown.

## Scope

- Consume charge through the normal activation contract; define owner, instance identity, lifetime, concurrent limits, and invalid-placement behavior.
- Spawn an actor from a Lubikan-supplied recipe and preserve owner attribution for damage/charge rules.
- Keep active summon ownership independent of changing the equipped selection and define dismissal policy.
- Clean up active attacks, modifiers, effects, and auxiliary structures through a typed departure path.

## Acceptance criteria

- [ ] A minimal fixture summon can activate without the full Bikanwarda encounter.
- [ ] Invalid activation cannot lose charge or spawn partial orphaned content under the agreed transactional policy.
- [ ] Owner death/replacement, timeout, and world reset retire all owned state.
- [ ] Normal departure is distinct from Died and does not emit kill rewards.

## Validation

- Exercise charge spend, placement rejection, rapid activation, limit enforcement, owner retirement, and interrupted departure.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](../lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)

This extends the Lubikan framework after its Self implementation. It must not become a dependency of the general Self gameplay release gate.

## Open decisions

- Decide activation cost, duration, concurrent summon count, dismissal/equip behavior, and charge attribution for summon-caused damage. These do not block Self delivery.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [Parent draft: Add Bikanwarda Ward and Enraged summons](../epics/e04-summon-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
