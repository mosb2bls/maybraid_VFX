# Summary

Generate one deformable chain mesh with a runtime-created armature and configurable segment count.

## Scope

- Generate mesh vertices, joint indices/weights, inverse bind poses, and joint entities from length, cross-section, and segment configuration.
- Accept a supplied chain pose/curve independently of the solver; use consistent segment/joint indexing.
- Cache compatible geometry/bind assets where practical; never rebuild them every frame.
- Expose anchors, UV distance convention, bounds updates, and limits on joints/segments. Keep the generic mechanism reusable for rope.

## Acceptance criteria

- [ ] Multiple lengths and segment counts produce one skinned mesh per chain and correct bind pose.
- [ ] Supplied bent poses deform smoothly without seam breaks, stretching discontinuities, or invalid normals.
- [ ] Bounds permit valid deformations to remain visible.
- [ ] Mesh generation has no dependency on Bikanwarda's rig or imported static armature.

## Validation

- Validate bind transforms/weights and inspect straight, bent, twisted, minimum, and longer configurations.
- Measure construction cost and steady pose update cost.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- A chain may use rigidly weighted link geometry inside the single mesh; confirm desired linked-chain versus continuous-energy-rope appearance.

## Relevant links

- [Existing character skin remapping](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/skin.rs)
- [Quadruped rig](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/rigs/src/rigs/quadruped_v0.rs)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
