# Summary

Create the architectural assembly used by Bikanwarda's encounter and summons.

## Scope

- Provide column shaft, capital, pedestal, configurable dimensions/material assignments, and chain attachment anchors.
- Use existing kit/component assembly conventions and stable transforms.
- Add appropriate physical cover colliders and terrain placement contract.
- Keep architectural assets independent of boss AI and Lubikan charge logic.

## Acceptance criteria

- [ ] An encounter and a runtime summon can instantiate the same column/pedestal assembly.
- [ ] The column blocks movement and participates in cover queries as intended.
- [ ] Anchors match the visual kit and support chain attachment.
- [ ] Scaling and material replacement do not misalign colliders or kit parts.

## Validation

- Inspect assembly dimensions, chain anchors, terrain fit, collisions, sight/trajectory cover, and repeated spawning.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- POM A11 enhances the final material; geometry/collision can land first. Decide summoned-column durability and departure lifetime with S04.

## Relevant links

- [Building component/kit library](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/components/src/lib.rs)
- [Existing urban POM surface shader](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/shaders/src/urban_surface.wgsl)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
