# Summary

Create a parameterized heavenly laser column for Bikanwarda and future effects.

## Scope

- Provide beam width, origin/ground endpoint, palette, duration, seed, activation/fade, and cancellation controls through the existing VFX conventions.
- Compose a readable column core, surrounding energy, ground-contact effect, and arrival/departure cues.
- Keep hazard/damage behavior in attack gameplay. Support the Bikanwarda ten-second active phase and tall sky-facing presentation.
- Bound particle counts, light use, and transparent overdraw; add a playground preset.

## Acceptance criteria

- [ ] A 7 m configured column reads clearly at boss gameplay distances and remains active for ten seconds.
- [ ] Two independent instances do not mutate shared assets or timing.
- [ ] Cancellation and normal completion leave no particles/lights/hosts alive indefinitely.
- [ ] Effect integrates through the existing VFX API with documented parameters.

## Validation

- Inspect near/far views, ground intersections, simultaneous instances, cancellation, and sustained-frame performance.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Beam width convention is shared with B04 and must be documented.

## Relevant links

- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [VFX architecture and playground](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/README.md)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
