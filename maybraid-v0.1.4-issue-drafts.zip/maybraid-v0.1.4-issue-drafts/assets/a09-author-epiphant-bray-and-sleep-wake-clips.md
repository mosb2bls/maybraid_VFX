# Summary

Add rig-correct animations for Bikanwarda's head-flick Bray and sleep phase.

## Scope

- Inspect the Epiphant GLB and armature dump directly before choosing articulation axes.
- Author Bray anticipation, head flick, and recovery plus sleep entry, held sleep, and wake.
- Integrate with existing clip identity, sampling/cache, and motion mailbox conventions.
- Expose or document timing cues for sonic emission and any heavy landing impact; gameplay consumes cues without being implemented inside pose sampling.

## Acceptance criteria

- [ ] Bray visibly flicks the head using the actual Epiphant rig and transitions naturally to idle.
- [ ] Sleep/wake can be interrupted by gameplay phase changes without a stuck pose.
- [ ] Wave/impact timing is repeatable and aligns with attack execution.
- [ ] Existing quadruped walk/run and character pose behavior remain usable.

## Validation

- Preview on the actual Epiphant at ordinary and boss scale, inspect bone axes, transitions, and interrupted sleep/Bray.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Quadruped animation implementation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/animations/src/rigs/quadruped.rs)
- [Quadruped rig](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/rigs/src/rigs/quadruped_v0.rs)
- [Character motion integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/motion/README.md)
- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
