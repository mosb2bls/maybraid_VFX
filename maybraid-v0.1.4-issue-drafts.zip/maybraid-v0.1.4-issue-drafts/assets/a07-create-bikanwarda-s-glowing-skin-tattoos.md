# Summary

Author tattoo markings and controllable emission for Bikanwarda's skinned body.

## Scope

- Create an authored tattoo mask/design and material recipe compatible with Epiphant body/head UVs or a documented alternative mapping.
- Expose color, intensity, and optional pulse parameters while preserving existing skin shading.
- Apply materials at the normal part-host ownership points; do not introduce a global post-spawn repaint scan.
- Document source assets, mapping, and how future boss variants recolor/reuse the effect.

## Acceptance criteria

- [ ] Tattoo markings follow the skinned character through idle, movement, and Bray.
- [ ] Glow is controllable per character and behaves under day/night lighting.
- [ ] Seams and mirrored parts are intentional and do not show obvious mapping breaks.
- [ ] Source assets and recipe are reproducible through the normal asset workflow.

## Validation

- Inspect the actual Epiphant mesh/UVs and posed model, then verify close and encounter-distance appearance.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Character assembly and material/animation ownership](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/CONTRIBUTING.md)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
