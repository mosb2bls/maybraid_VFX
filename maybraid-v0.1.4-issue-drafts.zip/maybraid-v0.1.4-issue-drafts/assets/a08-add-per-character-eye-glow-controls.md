# Summary

Extend eye presentation with a reliable runtime warning glow for God Beam.

## Scope

- Add per-character emission intensity/color and optional transition duration to the existing face-eye material path.
- Expose controls through the normal character part/material ownership mechanism.
- Support warning on/off, interruption reset, and ordinary eye appearance at zero glow.
- Keep the control generic and independent of Bikanwarda's combat code.

## Acceptance criteria

- [ ] One character's eye warning does not change other characters.
- [ ] Turning glow off restores normal eyes without rebuilding the character.
- [ ] God Beam warning can start/cancel/reset through a documented control.
- [ ] The effect remains readable at intended boss distance.

## Validation

- Preview off/on/transition states on Epiphant and another supported character; inspect material sharing and repeated toggles.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Existing eye/face material](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/shaders/src/face_material.rs)
- [Character assembly and material/animation ownership](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/CONTRIBUTING.md)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
