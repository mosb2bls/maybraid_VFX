# Summary

Add a chain surface whose energy glow and deterioration are controlled by durability.

## Scope

- Expose intact/damage amount, glow palette/intensity, seed, and break/fade progress through a material recipe.
- Design deterioration that communicates weakening along the chain without requiring mesh regeneration for every hit.
- Preserve surface readability under the game's stylized lighting and the skinned chain's UV convention.
- Accept global durability initially; keep localized damage an explicit optional extension.

## Acceptance criteria

- [ ] The same chain renders distinct intact, damaged, near-breaking, and released states.
- [ ] Updating one chain does not alter every shared material instance.
- [ ] Glow and deterioration work while the mesh bends and remain legible at encounter distance.
- [ ] Material has a preview and documented parameter ranges.

## Validation

- Inspect durability sweep, animated deformation, day/night lighting, and two differently damaged chains.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Coordinate UVs and break representation with A04/A06; material previews can use a temporary mesh.

## Relevant links

- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [VFX architecture and playground](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/README.md)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
