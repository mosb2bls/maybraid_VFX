# Summary

Create a general effects crate/API for spatial rumble from sonic attacks and heavy impacts.

## Scope

- Expose source position, range/falloff, intensity, duration/envelope, seed, and channels.
- Adapt to camera shake and existing PadRumble; provide ground feedback as a separate supported presentation channel.
- Compose concurrent sources with bounded output and apply camera shake without accumulating drift or changing locomotion.
- Provide intensity controls and cleanup when camera/player ownership changes; gameplay hazards remain independent.

## Acceptance criteria

- [ ] A dispatched effect produces distance-scaled camera/ground feedback and optional controller vibration.
- [ ] Bray and heavy landing can use the same API with different presets.
- [ ] Overlapping effects have predictable bounded output and finish without residual camera displacement.
- [ ] Keyboard/mouse play works without a connected controller.

## Validation

- Check stationary/moving camera, POV changes, simultaneous effects, distance falloff, pause, and owner replacement.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Specify whether ground feedback is dust/rings/material motion or actual ground displacement; prefer an explicit channel contract before implementing it.

## Relevant links

- [Existing controller rumble message](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/input/src/rumble.rs)
- [Player camera integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/player-camera/src/lib.rs)
- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
