# Summary

Drive chain joints and capsule colliders from a consistent anchored chain pose.

## Scope

- Represent column/body endpoints and chain length; resolve character socket attachment through normal assembly.
- Choose and document a bounded chain-motion approach, including tension/restraint behavior.
- Update the skinned pose and capsule transforms from one authoritative segment state.
- Separate chain skinning from simulation; permit a simple prescribed pose mode for previews and tests.

## Acceptance criteria

- [ ] The chain follows Bikanwarda and the column without detached endpoints.
- [ ] Capsules remain aligned to rendered segments and expose a stable damage target.
- [ ] The chained boss respects the agreed reach/restraint policy.
- [ ] Release and owner retirement remove restraint and retire owned colliders/joints.

## Validation

- Exercise boss movement/rotation, terrain contact, stretched endpoints, pause, chain release, and teardown.

## Dependencies and delivery boundary

- [A04: Generate runtime skinned rope and chain geometry](../assets/a04-generate-runtime-skinned-rope-and-chain-geometry.md)

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Decide whether restraint is gameplay kinematics, constraint simulation, or full physical joints; do not treat runtime armature creation as that decision.

## Relevant links

- [Existing character skin remapping](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/skin.rs)
- [Quadruped rig](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/rigs/src/rigs/quadruped_v0.rs)
- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
