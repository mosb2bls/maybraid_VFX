# Summary

Create Bikanwarda's final authored Epiphant presentation and physical dimensions.

## Scope

- Build from EpiphantConfig/character recipe with authored proportions, 20 m standing height, materials, eyes, and tattoos.
- Configure collision, sockets/emission positions, chain anchor, health-bar position, visual bounds, and visibility/LOD policy for a large actor.
- Integrate Bray and sleep/wake clips without duplicating character assembly or motion systems.
- Deliver a preview suitable for encounter and summon forms with parameterized form presentation.

## Acceptance criteria

- [ ] The assembled character is 20 m tall under the documented standing-height measurement.
- [ ] Collision and attack/chain sockets match the visual body at boss scale.
- [ ] Animated bounds and HUD anchors remain valid in Bray and sleep poses.
- [ ] Encounter, Ward, and Enraged can use the same authored actor recipe.

## Validation

- Inspect close/normal/far views, occlusion and LOD transitions, animation extremes, collider fit, and two instances.

## Dependencies and delivery boundary

- [A07: Create Bikanwarda's glowing skin tattoos](../assets/a07-create-bikanwarda-s-glowing-skin-tattoos.md)
- [A08: Add per-character eye glow controls](../assets/a08-add-per-character-eye-glow-controls.md)
- [A09: Author Epiphant Bray and sleep/wake clips](../assets/a09-author-epiphant-bray-and-sleep-wake-clips.md)

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Confirm height measurement excludes accessories and whether summons share the full encounter scale.

## Relevant links

- [Epiphant character recipe](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/species/epiphant.rs)
- [Character assembly and material/animation ownership](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/CONTRIBUTING.md)
- [Existing character skin remapping](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/lib/src/skin.rs)
- [Character motion integration](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/motion/README.md)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
