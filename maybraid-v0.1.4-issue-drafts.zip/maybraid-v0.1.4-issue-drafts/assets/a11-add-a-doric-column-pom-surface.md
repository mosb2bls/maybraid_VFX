# Summary

Extend architectural materials with stylized Doric fluting and column surface relief.

## Scope

- Use the existing urban POM/material conventions where suitable, with cylindrical mapping or a documented column UV convention.
- Author height/normal/color response for fluting; include quality bounds and distance/angle fading.
- Keep shaft outline, capital, pedestal, and cover collision in real geometry.
- Provide a column material preview that can be integrated into reusable kits.

## Acceptance criteria

- [ ] Fluting reads as relief from representative viewing angles and blends cleanly into distant shading.
- [ ] UV seam and curved-surface grazing views do not show major discontinuities.
- [ ] Material does not change collision or claim POM produces the physical cover shape.
- [ ] Sampling work is bounded and configurable for a large visible column.

## Validation

- Inspect orbiting views, close/grazing/distant shots, day/night lighting, and shader performance.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [Existing urban POM surface shader](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/shaders/src/urban_surface.wgsl)
- [Material reference API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/material-ref/src/lib.rs)
- [Building component/kit library](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/urbanization/buildings/components/src/lib.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
