# Summary

Create propagating sonic-wave presentation for Bray without embedding combat behavior.

## Scope

- Expose emission transform/socket, speed, range, spread, wave count, lifetime, palette, and seed.
- Use particles and/or effect meshes that visibly communicate propagation and direction.
- Support cancellation and effect ownership through the existing VFX lifecycle.
- Keep gameplay hit geometry supplied by attack execution; add a playable preview preset.

## Acceptance criteria

- [ ] Waves visibly propagate from the intended emission point with configurable travel/spread.
- [ ] Presentation can match B04's authoritative wavefront timings.
- [ ] Repeated spawning and cancellation do not leak effect instances.
- [ ] Effect reads at the scale of a 20 m boss without obscuring the whole encounter.

## Validation

- Inspect moving emitters, near/far cameras, several palettes, overlapping waves, and cancellation.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Relevant links

- [VFX library and spawning API](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/src/lib.rs)
- [VFX architecture and playground](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/vfx/lib/README.md)
- [Quadruped animation implementation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/animations/src/rigs/quadruped.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
