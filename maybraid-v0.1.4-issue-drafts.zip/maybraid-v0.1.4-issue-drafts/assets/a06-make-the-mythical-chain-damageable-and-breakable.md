# Summary

Connect chain capsule hits to durability and a one-shot release outcome.

## Scope

- Route child-collider hits to the intended chain health/durability target using the existing damage seam.
- Drive material deterioration from durability and emit a typed chain-broken signal at zero.
- Detach restraint/anchors and perform the agreed visual break behavior.
- Keep chain destruction distinct from boss death; report encounter release through B06.

## Acceptance criteria

- [ ] Attacking any configured chain capsule damages the correct chain.
- [ ] One physical interaction cannot multiply damage through overlapping capsules.
- [ ] Zero durability breaks once and frees Bikanwarda without killing her.
- [ ] Visual state and collision/restraint cleanup follow the same broken outcome.

## Validation

- Test child hit resolution, overlapping capsules, lethal chain hit, duplicate signals, simultaneous boss death, and streaming.

## Dependencies and delivery boundary

- [A05: Add anchored chain motion and capsule collision](../assets/a05-add-anchored-chain-motion-and-capsule-collision.md)
- [B06: Preserve Bikanwarda encounter outcomes and award summon unlocks](../boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md)

This asset lane can be developed in a playground using fixtures. Named gameplay integrations do not require the complete encounter to exist first.

## Open decisions

- Final material A03 can integrate later. Decide whether break is whole-chain dissolution, a localized gap, or severed pieces; one-mesh rendering does not itself define severing.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [Parent draft: Build reusable Bikanwarda assets and effects](../epics/e03-assets-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
