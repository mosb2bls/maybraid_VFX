# Summary

Provide an extensible enter/stay/exit system for awarding points from occupied generated cells.

## Scope

- Resolve the actor's semantic cell identity and expose occupancy changes plus periodic rule evaluation.
- Allow rules to match cell affiliation, forest/grove information, and construction presence; use spatial indexing and change-driven cached metadata.
- Emit awards through the shared charge pipeline; support a Self/demo rule so the system can be developed without Bikanwarda.
- Define timer ownership, re-entry behavior, overlapping matches, unloaded metadata, and pause semantics. Never infer semantic membership from rendered meshes.

## Acceptance criteria

- [ ] A configured occupancy rule can award Self charge on a timed interval.
- [ ] Leaving a qualifying region stops awards; repeated visual streaming cannot duplicate rewards.
- [ ] Several overlapping qualifying constructions do not multiply a single cell reward unless configured to do so.
- [ ] Rule extension requires no global vegetation scan each frame and no dependency on Bikanwarda.

## Validation

- Test enter/exit, exact interval boundaries, re-entry, overlapping cells/layers, large time steps, and absent metadata.
- Profile a stationary actor and cell transitions in a representative forest.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](../lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Specify whether 'forest cell with a construction' means any such construction anywhere in the forest cell or the actor's grove tile; keep matching granularity explicit.

## Relevant links

- [HCSG generation and presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/lod/lib/src/hcsg.rs)
- [Forest/grove generation and semantic presentation](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/chico/src/hcsg.rs)
- [Semantic grove identity and recipes](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/chico/src/grove.rs)
- [Sope's Banyan construction](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/vegetation/sbs-trees/src/sopes_banyan.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
