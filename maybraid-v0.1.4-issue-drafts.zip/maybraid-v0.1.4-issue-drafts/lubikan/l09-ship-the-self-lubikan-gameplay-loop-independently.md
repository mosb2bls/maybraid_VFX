# Summary

Integrate and validate points, charge, activation, healing, controls, and HUD as a standalone v0.1.4 delivery.

## Scope

- Wire general Lubikan plugins into ordinary gameplay with Self as the default.
- Deliver the complete loop: interaction → points → Self charge → readiness → activation → healing.
- Include periodic cell awards through a configurable demonstration rule; the generic rule framework can land separately from that content.
- Provide short gameplay documentation and a repeatable validation scenario. External Lubikan entries used in cycling tests may be fixtures.

## Acceptance criteria

- [ ] The normal world boots and the complete Self loop works with every Bikanwarda/encounter plugin disabled or absent.
- [ ] Weapon/skill-map category cycling and Select map access work with existing gameplay.
- [ ] Gameplay points are accounted for once, independently of HUD animation.
- [ ] Pause, death, replacement, and reset leave no stale healing session or HUD owner.

## Validation

- Run one focused integration scenario and manually verify the Self-only world.
- Exercise HUD-disabled accounting and rapid control/overlay changes.

## Dependencies and delivery boundary

- [L04: Implement Self charge activation and health regeneration](../lubikan/l04-implement-self-charge-activation-and-health-regeneration.md)
- [L06: Select inventory cycling categories with the D-pad](../lubikan/l06-select-inventory-cycling-categories-with-the-d-pad.md)
- [L07: Display active Lubikan charge above player health](../lubikan/l07-display-active-lubikan-charge-above-player-health.md)
- [L08: Animate point feedback toward the credited Lubikan HUD](../lubikan/l08-animate-point-feedback-toward-the-credited-lubikan-hud.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- This is an independent release gate, not a dependency on any boss, chain, column, or summon asset.

## Relevant links

- [World weapon/skill-map cycling and loadout synchronization](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/weapon.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Controller intent production](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/produce.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
