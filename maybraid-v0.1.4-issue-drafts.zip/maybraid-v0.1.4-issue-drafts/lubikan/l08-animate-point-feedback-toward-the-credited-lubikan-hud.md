# Summary

Animate awarded points from interaction locations to the charge display using authoritative charge-change results.

## Scope

- Project a supplied world origin to the HUD; provide sensible presentation for occupancy rewards and offscreen origins.
- Show signed values and distinguish gains from penalties; aggregate busy combat feedback within bounded UI work.
- Preserve the credited Lubikan identity if selection changes while feedback is travelling.
- Credit charge before animation starts; clear presentation safely when the HUD or player is retired.

## Acceptance criteria

- [ ] Combat and occupancy rewards fly toward Self's charge display with no Bikanwarda content.
- [ ] Displayed values match authoritative awards and do not affect accounting.
- [ ] Selection changes never visually credit the wrong account; hidden/offscreen cases fail gracefully.
- [ ] Point feedback remains bounded during multi-hit area attacks.

## Validation

- Visually check simultaneous awards, penalties, offscreen origins, HUD hiding, equip changes, and player death.

## Dependencies and delivery boundary

- [L02: Move gameplay points into equipped Lubikan charge rules](../lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [L07: Display active Lubikan charge above player health](../lubikan/l07-display-active-lubikan-charge-above-player-health.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Relevant links

- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Existing combat score ingestion](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/score.rs)
- [Player health HUD](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/vitals.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
