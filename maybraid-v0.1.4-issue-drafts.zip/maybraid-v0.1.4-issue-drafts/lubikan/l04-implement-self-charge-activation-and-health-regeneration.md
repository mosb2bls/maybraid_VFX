# Summary

Make the null Lubikan usable immediately by spending Self charge to activate the specified healing behavior.

## Scope

- Use the normal Lubikan activation path and a semantic activation intent with a configurable input binding.
- Heal 5% of maximum health per game-time second. With no damage during the activation, stop at 100%; after damage, cap continuing healing at 70%.
- Latch accepted positive damage during the session and terminate cleanly on death, invalid owner, or session teardown.
- Never reduce existing health to enforce a cap. Prevent duplicate concurrent healing sessions and undefined healing of a downed body.

## Acceptance criteria

- [ ] Self can be charged and activated in the normal world without any proper Lubikan.
- [ ] Healing is frame-rate independent and scales with maximum health.
- [ ] Damage during healing switches the cap to 70%; a player already above that cap receives no further healing and loses no health from the cap itself.
- [ ] Activation consumes charge according to the configured policy and exposes active/completed state to presentation.

## Validation

- Test undamaged healing to full, damaged healing to 70%, starting above 70%, lethal damage, pause, and player replacement.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](../lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [L03: Add bounded damage history and durable attribution](../lubikan/l03-add-bounded-damage-history-and-durable-attribution.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Proposed interpretation: damage lowers the remainder's healing ceiling and does not cancel the whole event. Confirm before implementation.
- Choose the default activation binding and cost; no Bikanwarda work is required to make that choice.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Character gameplay intents](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/intent.rs)
- [Player health HUD](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/vitals.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
