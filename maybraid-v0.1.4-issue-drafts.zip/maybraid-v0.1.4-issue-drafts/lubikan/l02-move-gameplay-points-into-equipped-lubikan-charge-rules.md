# Summary

Route world interaction points into the active Lubikan's charge instead of calculating gameplay awards inside the combat HUD.

## Scope

- Consume applied combat outcomes and evaluate equipped-Lubikan rules for signed point changes, with an initial configurable Self policy.
- Emit an authoritative charge-change result carrying recipient, credited Lubikan identity, signed amount, reason, and optional world origin.
- Credit gameplay immediately; UI animations consume the result. Snapshot the credited selection at event resolution.
- Remove duplicate gameplay point accounting from CombatScore and hit-marker code. Retain mode statistics only where useful and define how their display relates to charge.

## Acceptance criteria

- [ ] Self earns charge through ordinary combat with no Bikanwarda installed.
- [ ] One resolved interaction produces one authoritative award; late readers and HUD visibility cannot duplicate or suppress it.
- [ ] Negative changes floor at zero and positive changes respect capacity.
- [ ] Point labels and the charge HUD consume actual rule outcomes rather than the old hardcoded hit/down values.

## Validation

- Exercise lethal hits, nonlethal hits, zero effective damage, unrelated attackers, and equip changes.
- Verify charge with HUD disabled and confirm existing training-mode statistics still behave intentionally.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Confirm whether hit and kill awards stack. For Self, keep reward weights configurable pending balance.
- DamageApplied.amount currently reflects the requested scaled amount rather than a measured HP delta; ensure zero/invalid hits and overkill cannot produce unintended awards.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Existing combat score ingestion](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/score.rs)
- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Damage-driven threat intelligence](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/intelligence/threat/damage/src/lib.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
