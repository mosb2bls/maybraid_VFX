# Summary

Add the Lubikan charge HUD with Self as a complete initial display.

## Scope

- Show active identity, current/capacity charge, activation eligibility, and active healing/summon state above player health.
- Implement a stable HUD destination anchor for flying points and a cue for the selected cycling category.
- Use authoritative model state and share gameplay/menu visibility rules with player vitals.
- Handle selection changes, charge loss, maximum charge, player respawn, and different viewport sizes.

## Acceptance criteria

- [ ] A Self-only game shows a complete usable charge display and healing state.
- [ ] Charge values match gameplay even when the HUD was hidden during awards.
- [ ] Readiness and negative changes are distinguishable; HUD construction never creates gameplay charge state.
- [ ] The display remains correctly positioned above health and does not require boss textures or portraits.

## Validation

- Visually verify normal, ready, healing, empty, hidden, and respawn states at several viewport sizes.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [L02: Move gameplay points into equipped Lubikan charge rules](../lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Relevant links

- [Combat HUD and point markers](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/lib.rs)
- [Player health HUD](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/vitals.rs)
- [Existing combat score ingestion](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/combat-hud/src/score.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
