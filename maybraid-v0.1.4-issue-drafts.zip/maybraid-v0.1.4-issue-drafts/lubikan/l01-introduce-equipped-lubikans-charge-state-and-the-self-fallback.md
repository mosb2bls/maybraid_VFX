# Summary

Introduce the reusable Lubikan model with Self as its first playable implementation, independently of Bikanwarda.

## Scope

- Represent definition identity, owned/unlocked entries, equipped selection, bounded charge, readiness, and activation state. Proposed names are design guidance, not fixed API requirements.
- Treat no equipped external Lubikan as Self through the same public model. Keep charge and activation state in gameplay; HUD availability must not affect it.
- Define charge ownership across equip/unequip, player-body replacement, and session restart. Keep each Lubikan's account distinct.
- Provide configurable Self capacity and activation cost so balancing does not block shipping the framework.

## Acceptance criteria

- [ ] A normal game with no boss content registers Self and exposes its charge/readiness.
- [ ] Positive and negative charge mutations clamp to valid limits; insufficient charge cannot activate.
- [ ] Switching selection does not transfer charge between accounts, duplicate ownership, or lose Self.
- [ ] Definition/state APIs can be consumed by future Lubikans without adding Bikanwarda dependencies.

## Validation

- Exercise account bounds, selection fallback, activation eligibility, and player replacement.
- Run the ordinary world with all Bikanwarda plugins/assets absent.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Self capacity, activation cost, and charge persistence after death require balance decisions; expose them as configuration.

## Relevant links

- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [World weapon/skill-map cycling and loadout synchronization](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/weapon.rs)
- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
