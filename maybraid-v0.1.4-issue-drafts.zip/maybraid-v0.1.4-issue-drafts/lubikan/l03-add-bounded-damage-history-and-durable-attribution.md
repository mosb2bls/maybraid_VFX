# Summary

Maintain queryable recent damage history for gameplay lookback, including Self healing and future Lubikan affiliation rules.

## Scope

- Record accepted damage with game-time timestamp, recipient, effective amount, source, and identity/affiliation information needed after despawn.
- Use a bounded retention policy and query API by target and interval; avoid unbounded per-frame growth.
- Expose summon-owner attribution as an extension seam. Distinguish direct attacker from responsible owner.
- Define ordering with DamageSystems and lifecycle cleanup so events remain usable after a victim is retired.

## Acceptance criteria

- [ ] History answers whether a player took positive damage since a healing activation began.
- [ ] Expired records are removed and both time and capacity bounds are respected.
- [ ] Queries remain meaningful after source/victim entity despawn and do not match recycled entity identities.
- [ ] Damage history has no dependency on Lubikan visuals or Bikanwarda.

## Validation

- Exercise interval boundaries, multiple hits in one frame, source despawn, capacity overflow, and session reset.

## Dependencies and delivery boundary

No hard dependency on another proposed issue. Use existing repository foundations and fixtures/placeholders where needed.

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Choose retention duration and overflow semantics; an active healing session must latch damage rather than rely forever on retained records.

## Relevant links

- [Health, Hit, DamageApplied, and Died](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lib.rs)
- [Damage application and child-target resolution](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/apply.rs)
- [Downed state and delayed despawn](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/damage/src/lifecycle.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
