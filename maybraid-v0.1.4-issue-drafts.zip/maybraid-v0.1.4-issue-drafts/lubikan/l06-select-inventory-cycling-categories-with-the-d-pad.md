# Summary

Use the D-pad to select which equipped inventory queue Y cycles, including Self and future Lubikans.

## Scope

- Right selects Weapons, Down Skill Maps, and Left Lubikans; Y cycles forward in the selected queue.
- Add Lubikan selection to the inventory/equipment model, with Self available even when no external Lubikan is owned.
- Remove gameplay D-pad map open/close and direct skill-map cycling. Keep Select/View as map toggle and retain intentional keyboard equivalents.
- Respect menu, text-input, map, and respawn-picker focus. Add a visible active-category cue and update control help.

## Acceptance criteria

- [ ] Weapons and skill maps cycle in the live world using category selection followed by Y.
- [ ] The Lubikan category works with a Self-only loadout; single-entry and empty queues are safe.
- [ ] Selecting a category does not itself cycle an item or activate a skill/summon.
- [ ] Select opens/closes the map and Tab continues its intended inventory behavior; UI navigation retains its own D-pad routing.

## Validation

- Exercise every category, queue wraparound, one-entry queues, held versus pressed input, keyboard bindings, and overlay/respawn focus.

## Dependencies and delivery boundary

- [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)

This issue may land before Bikanwarda. Self is the production implementation used to validate the general system; do not require boss definitions, chain/column assets, tattoos, or summon forms.

## Open decisions

- Up remains unassigned in this proposal. Activation is a separate intent/binding, not Y cycling.

## Relevant links

- [Inventory slots and equipped queues](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/layers/mobs/characters/items/src/inventory.rs)
- [World weapon/skill-map cycling and loadout synchronization](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/weapon.rs)
- [Character gameplay intents](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/intent.rs)
- [Controller intent production](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/controllers/character/src/produce.rs)
- [World overhead map](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/map_view.rs)
- [First-spawn selection and player lifecycle](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/maybraid/world/lib/src/player_lifecycle.rs)
- [Parent draft: Ship general Lubikan gameplay with Self](../epics/e01-lubikan-epic.md)

_Source baseline: [main at cc20b8a](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6). Proposed API names are illustrative. This draft does not create a GitHub issue._
