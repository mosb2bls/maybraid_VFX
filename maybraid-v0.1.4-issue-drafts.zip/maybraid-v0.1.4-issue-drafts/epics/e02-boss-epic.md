# Summary

Build Bikanwarda as an authored 20 m Epiphant encounter near the universal initial spawn, chained to a column, with reusable attacks, sleep/recovery, and kill/free outcomes.

## Required encounter behavior

- Parade of Explosions: warned line toward the player followed by advancing explosions.
- God Beam: eye-glow warning followed by a 7 m heavenly column active for 10 seconds.
- Bray: head flick followed by sonic waves and rumble.
- Sleep at 20% health for 15 seconds and recover to 50%; wake early if sleeping health reaches 10%. Recovery/interruption details remain explicit open decisions in B05.
- Kill unlocks Enraged; breaking the chain/freeing her unlocks Ward.

## Child issues

- [ ] [B01: Add HCSG boss generation and Scripted authoring](../boss/b01-add-hcsg-boss-generation-and-scripted-authoring.md)
- [ ] [B02: Build Bikanwarda's encounter near the universal initial spawn](../boss/b02-build-bikanwarda-s-encounter-near-the-universal-initial-spawn.md)
- [ ] [B03: Add reusable boss attack timing, hazards, and telegraphs](../boss/b03-add-reusable-boss-attack-timing-hazards-and-telegraphs.md)
- [ ] [B04: Implement Bikanwarda's Parade, God Beam, and Bray attacks](../boss/b04-implement-bikanwarda-s-parade-god-beam-and-bray-attacks.md)
- [ ] [B05: Implement Bikanwarda's sleep, recovery, and waking phase](../boss/b05-implement-bikanwarda-s-sleep-recovery-and-waking-phase.md)
- [ ] [B06: Preserve Bikanwarda encounter outcomes and award summon unlocks](../boss/b06-preserve-bikanwarda-encounter-outcomes-and-award-summon-unlocks.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)
