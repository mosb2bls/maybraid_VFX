# Summary

Ship a complete Lubikan gameplay loop through Self, the null/default Lubikan, before Bikanwarda is available. Points, charge, activation, healing, inventory category selection, and HUD feedback are immediately usable general gameplay.

## Independent release gate

The first production Lubikan is Self. L09 demonstrates the full loop with no Bikanwarda plugins or assets. Do not defer charge, HUD, points, healing, or cycling until a proper summon exists. Cell rewards are an independently extensible lane and can be demonstrated with a configured Self rule.

## Child issues

- [ ] [L01: Introduce equipped Lubikans, charge state, and the Self fallback](../lubikan/l01-introduce-equipped-lubikans-charge-state-and-the-self-fallback.md)
- [ ] [L02: Move gameplay points into equipped Lubikan charge rules](../lubikan/l02-move-gameplay-points-into-equipped-lubikan-charge-rules.md)
- [ ] [L03: Add bounded damage history and durable attribution](../lubikan/l03-add-bounded-damage-history-and-durable-attribution.md)
- [ ] [L04: Implement Self charge activation and health regeneration](../lubikan/l04-implement-self-charge-activation-and-health-regeneration.md)
- [ ] [L05: Add semantic cell occupancy and periodic charge rewards](../lubikan/l05-add-semantic-cell-occupancy-and-periodic-charge-rewards.md)
- [ ] [L06: Select inventory cycling categories with the D-pad](../lubikan/l06-select-inventory-cycling-categories-with-the-d-pad.md)
- [ ] [L07: Display active Lubikan charge above player health](../lubikan/l07-display-active-lubikan-charge-above-player-health.md)
- [ ] [L08: Animate point feedback toward the credited Lubikan HUD](../lubikan/l08-animate-point-feedback-toward-the-credited-lubikan-hud.md)
- [ ] [L09: Ship the Self Lubikan gameplay loop independently](../lubikan/l09-ship-the-self-lubikan-gameplay-loop-independently.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.
- [ ] Self-only gameplay ships independently with the entire Bikanwarda content stack absent.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)
