# Summary

Deliver independent reusable visual/physical assets for Bikanwarda, using existing VFX, materials, character assembly, architectural kits, and rumble foundations.

## Parallel asset delivery

Effects/materials should have standalone playground presets. Runtime chain skinning and chain motion are separate contracts. Architectural geometry owns silhouette and physical cover; POM owns surface relief. Final assembly validates the combined 20 m character.

## Child issues

- [ ] [A01: Create reusable God Beam VFX](../assets/a01-create-reusable-god-beam-vfx.md)
- [ ] [A02: Create reusable sonic-wave VFX](../assets/a02-create-reusable-sonic-wave-vfx.md)
- [ ] [A03: Create a glowing mythical chain material with damage deterioration](../assets/a03-create-a-glowing-mythical-chain-material-with-damage-deterioration.md)
- [ ] [A04: Generate runtime skinned rope and chain geometry](../assets/a04-generate-runtime-skinned-rope-and-chain-geometry.md)
- [ ] [A05: Add anchored chain motion and capsule collision](../assets/a05-add-anchored-chain-motion-and-capsule-collision.md)
- [ ] [A06: Make the mythical chain damageable and breakable](../assets/a06-make-the-mythical-chain-damageable-and-breakable.md)
- [ ] [A07: Create Bikanwarda's glowing skin tattoos](../assets/a07-create-bikanwarda-s-glowing-skin-tattoos.md)
- [ ] [A08: Add per-character eye glow controls](../assets/a08-add-per-character-eye-glow-controls.md)
- [ ] [A09: Author Epiphant Bray and sleep/wake clips](../assets/a09-author-epiphant-bray-and-sleep-wake-clips.md)
- [ ] [A10: Add reusable spatial camera and ground rumble](../assets/a10-add-reusable-spatial-camera-and-ground-rumble.md)
- [ ] [A11: Add a Doric column POM surface](../assets/a11-add-a-doric-column-pom-surface.md)
- [ ] [A12: Create reusable Doric column and pedestal kits](../assets/a12-create-reusable-doric-column-and-pedestal-kits.md)
- [ ] [A13: Assemble and validate the 20 m Bikanwarda character](../assets/a13-assemble-and-validate-the-20-m-bikanwarda-character.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)
