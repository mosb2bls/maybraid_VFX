# Summary

Extend the already-shippable Lubikan framework with Bikanwarda's Ward and Enraged forms, shared boss attacks, affiliation rewards, cover column, Ward buff, and glowing departure.

## Required form behavior

- Both forms reuse encounter attacks.
- Enraged attacks anything, including the summoner.
- Ward attacks the summoner's enemies and boosts strength.
- Both spawn with a physical cover column and depart through glow/fade rather than ordinary death.
- Animal damage/kill: −5/−10 charge. Raider damage/kill: +5/+25. Qualifying Sope's Banyan forest occupancy: +5 per five seconds.

## Child issues

- [ ] [S01: Add Lubikan summon activation and owned lifecycle](../summon/s01-add-lubikan-summon-activation-and-owned-lifecycle.md)
- [ ] [S02: Implement Bikanwarda Lubikan affiliations and charge rules](../summon/s02-implement-bikanwarda-lubikan-affiliations-and-charge-rules.md)
- [ ] [S03: Implement Bikanwarda Ward and Enraged combat policies](../summon/s03-implement-bikanwarda-ward-and-enraged-combat-policies.md)
- [ ] [S04: Add Bikanwarda's column, Ward strength boost, and glowing departure](../summon/s04-add-bikanwarda-s-column-ward-strength-boost-and-glowing-departure.md)

## Acceptance criteria

- [ ] Child deliveries integrate through the existing repository architecture and explicit ownership/lifecycle contracts.
- [ ] The required gameplay or preview is repeatable and documented.
- [ ] Open behavior decisions are resolved in the owning child before implementation is called complete.

## Relevant links

- [Repository baseline](https://github.com/ramate-io/maybraid/commit/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6)
- [Issue conventions](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/CONTRIBUTING.md)
- [Issue publishing helper](https://github.com/ramate-io/maybraid/blob/cc20b8a84b73a29d1e4c67d48c23c7d0feb9dfb6/bin/publish-gh-issue.md)
